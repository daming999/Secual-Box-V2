//
//  DeleteRoomView.h
//  TemperatureControlBLE
//
//  Created by 黄文雨 on 2018/8/29.
//  Copyright © 2018年 wenyu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DeleteRoomView : UIView
@property (nonatomic,strong) UILabel *titleLb;
@property (nonatomic,strong) UILabel *TipsLb;
@end
