//
//  SetWenduView.h
//  TemperatureControlBLE
//
//  Created by 黄文雨 on 2018/8/28.
//  Copyright © 2018年 wenyu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CircleIndicatorView.h"
#import "InvokHeadFile.pch"

@interface SetWenduView : UIView
@property (nonatomic,strong) CircleIndicatorView *circleIndicatorView;
@property (nonatomic,strong) UILabel *titleLb;
@property (nonatomic,strong) UILabel *TemperatureValueLb;
@end
