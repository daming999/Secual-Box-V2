//
//  SetWenduView.m
//  TemperatureControlBLE
//
//  Created by 黄文雨 on 2018/8/28.
//  Copyright © 2018年 wenyu. All rights reserved.
//

#import "SetWenduView.h"
#import "InvokHeadFile.pch"

@implementation SetWenduView
@synthesize titleLb;
@synthesize TemperatureValueLb;
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

-(id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor clearColor];
    }
    return self;
}

-(void)drawRect:(CGRect)rect
{
    CGFloat BackVW = ScrWidth-20, BackVH = ScrHeight-100;
    
    UIView *BackView = [[UIView alloc] initWithFrame:CGRectMake(10, 80, BackVW, BackVH)];
    BackView.backgroundColor = [UIColor whiteColor];
    [self addSubview: BackView];
    
    titleLb = [[UILabel alloc] initWithFrame:CGRectMake(0, 15, BackVW, 30)];
    titleLb.text = NSLocalizedString(@"Comfort temperature settings", nil);
    titleLb.textColor = TextGaryColor;
    titleLb.textAlignment = UITextAlignmentCenter;
    titleLb.font = [UIFont systemFontOfSize:15.0];
    [BackView addSubview:titleLb];
    
    UIImageView *LineImg = [[UIImageView alloc] initWithFrame:CGRectMake(0, titleLb.frame.origin.y + 45, BackVW, 1)];
    LineImg.backgroundColor = TextGaryColor;
    [BackView addSubview:LineImg];
    
    TemperatureValueLb = [[UILabel alloc] initWithFrame:CGRectMake((BackVW-80)/2, LineImg.frame.origin.y+40, 80, 80)];
    TemperatureValueLb.text = NSLocalizedString(@"50", nil);
    TemperatureValueLb.textColor = TextGaryColor;
    TemperatureValueLb.font = [UIFont systemFontOfSize:50.0];
    TemperatureValueLb.textAlignment = UITextAlignmentCenter;
   

    self.circleIndicatorView = [[CircleIndicatorView alloc] init];
    self.circleIndicatorView.frame = CGRectMake(50, 100,  ScrWidth-100, 300);
    self.circleIndicatorView.minValue = 0;
    self.circleIndicatorView.maxValue = 40;
    self.circleIndicatorView.innerAnnulusValueToShowArray = @[@0, @10, @20, @30, @40];
    self.circleIndicatorView.backgroundColor = [UIColor clearColor];
    self.circleIndicatorView.indicatorValue = 15;
    [BackView addSubview:self.circleIndicatorView];
    self.circleIndicatorView.minusBlock = ^{
        NSLog(@"点击了 -");
        NSLog(@"这里是多少 = %d",self.circleIndicatorView.indicatorValue);
        self.circleIndicatorView.indicatorValue -= 1;
    };
    self.circleIndicatorView.addBlock = ^{
        NSLog(@"点击了 +");
        self.circleIndicatorView.indicatorValue += 1;
    };
    
     [BackView addSubview:TemperatureValueLb];
    
    CGFloat BackViewjjH = BackView.frame.origin.y + BackVH - 145;
    
    UIImageView *endLineImg = [[UIImageView alloc] initWithFrame:CGRectMake(0, BackVH-55, BackVW, 1)];
    endLineImg.backgroundColor = TextGaryColor;
    [BackView addSubview:endLineImg];
    
    
    UIButton *CancleBtn = [[UIButton alloc] initWithFrame:CGRectMake(50, endLineImg.frame.origin.y+5, 45, 45)];
    CancleBtn.titleLabel.font = [UIFont systemFontOfSize:15.0];
    CancleBtn.tag = 300;
    [CancleBtn setImage:[UIImage imageNamed:@"yacha_deep"] forState:UIControlStateNormal];
    CancleBtn.backgroundColor = BackGroundBlueColor;
    [CancleBtn setTitleColor:TextWhiteColor forState:UIControlStateNormal];
    [CancleBtn addTarget:self action:@selector(CancleBtn:) forControlEvents:UIControlEventTouchUpInside];
    [BackView addSubview:CancleBtn];
    
    UIButton *ComfirBtn = [[UIButton alloc] initWithFrame:CGRectMake(BackVW-95, endLineImg.frame.origin.y+5, 45, 45)];
    ComfirBtn.titleLabel.font = [UIFont systemFontOfSize:15.0];
    ComfirBtn.tag = 300;
    [ComfirBtn setImage:[UIImage imageNamed:@"gouxuan_deep"] forState:UIControlStateNormal];
    ComfirBtn.backgroundColor = BackGroundBlueColor;
    [ComfirBtn setTitleColor:TextWhiteColor forState:UIControlStateNormal];
    [ComfirBtn addTarget:self action:@selector(ComfirBtn:) forControlEvents:UIControlEventTouchUpInside];
    [BackView addSubview:ComfirBtn];
}

-(void)CancleBtn:(id)send{
    [self removeFromSuperview];
}

-(void)ComfirBtn:(id)send{
    
}

@end
