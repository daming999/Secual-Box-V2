//
//  RenameView.m
//  TemperatureControlBLE
//
//  Created by 黄文雨 on 2018/8/29.
//  Copyright © 2018年 wenyu. All rights reserved.
//

#import "RenameView.h"
#import "InvokHeadFile.pch"

@implementation RenameView
@synthesize titleLb;
@synthesize TipsLb;


-(id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor clearColor];
    }
    return self;
}

-(void)drawRect:(CGRect)rect
{
    CGFloat BackVW = ScrWidth-20, BackVH = 200;
    
    UIView *BackView = [[UIView alloc] initWithFrame:CGRectMake(10, 180, BackVW, BackVH)];
    BackView.backgroundColor = [UIColor whiteColor];
    [self addSubview: BackView];
    
    titleLb = [[UILabel alloc] initWithFrame:CGRectMake(0, 15, BackVW, 30)];
    titleLb.text = NSLocalizedString(@"Comfort temperature settings", nil);
    titleLb.textColor = TextGaryColor;
    titleLb.textAlignment = UITextAlignmentCenter;
    titleLb.font = [UIFont systemFontOfSize:15.0];
    [BackView addSubview:titleLb];
    
    UIImageView *LineImg = [[UIImageView alloc] initWithFrame:CGRectMake(0, titleLb.frame.origin.y + 45, BackVW, 1)];
    LineImg.backgroundColor = TextGaryColor;
    [BackView addSubview:LineImg];
    
    TipsLb = [[UILabel alloc] initWithFrame:CGRectMake(30, LineImg.frame.origin.y+12, BackVW, 30)];
    TipsLb.text = NSLocalizedString(@"enter a new name", nil);
    TipsLb.textColor = TextGaryColor;
    TipsLb.numberOfLines = 0;
    TipsLb.font = [UIFont systemFontOfSize:15.0];
    TipsLb.textAlignment = UITextAlignmentLeft;
    [BackView addSubview:TipsLb];
    
    UITextField *RenameTf = [[UITextField alloc] initWithFrame:CGRectMake(30,TipsLb.frame.origin.y+30, 150,30)];
    RenameTf.borderStyle = UITextBorderStyleRoundedRect;
    RenameTf.keyboardType = UIKeyboardTypeDefault;
    RenameTf.autocorrectionType = UITextAutocorrectionTypeYes;
    RenameTf.placeholder = NSLocalizedString(@"请输入名字", nil);
    RenameTf.returnKeyType = UIReturnKeyDone;
    RenameTf.clearButtonMode = UITextFieldViewModeWhileEditing;
    [RenameTf setBackgroundColor:[UIColor whiteColor]];
    RenameTf.delegate = self;
    [BackView addSubview:RenameTf];
    
    CGFloat BackViewjjH = BackView.frame.origin.y + BackVH - 145;
    
    UIImageView *endLineImg = [[UIImageView alloc] initWithFrame:CGRectMake(0, BackVH-55, BackVW, 1)];
    endLineImg.backgroundColor = TextGaryColor;
    [BackView addSubview:endLineImg];
    
    //丫杈
    UIButton *CancleBtn = [[UIButton alloc] initWithFrame:CGRectMake(50, endLineImg.frame.origin.y+5, 45, 45)];
    CancleBtn.titleLabel.font = [UIFont systemFontOfSize:15.0];
    CancleBtn.tag = 300;
    [CancleBtn setImage:[UIImage imageNamed:@"yacha_deep"] forState:UIControlStateNormal];
    CancleBtn.backgroundColor = BackGroundBlueColor;
    [CancleBtn setTitleColor:TextWhiteColor forState:UIControlStateNormal];
    [CancleBtn addTarget:self action:@selector(CancleBtn:) forControlEvents:UIControlEventTouchUpInside];
    [BackView addSubview:CancleBtn];
    
    //勾选
    UIButton *ComfirBtn = [[UIButton alloc] initWithFrame:CGRectMake(BackVW-95, endLineImg.frame.origin.y+5, 45, 45)];
    ComfirBtn.titleLabel.font = [UIFont systemFontOfSize:15.0];
    ComfirBtn.tag = 300;
    [ComfirBtn setImage:[UIImage imageNamed:@"gouxuan_deep"] forState:UIControlStateNormal];
    ComfirBtn.backgroundColor = BackGroundBlueColor;
    [ComfirBtn setTitleColor:TextWhiteColor forState:UIControlStateNormal];
    [ComfirBtn addTarget:self action:@selector(ComfirBtn:) forControlEvents:UIControlEventTouchUpInside];
    [BackView addSubview:ComfirBtn];
}

-(void)CancleBtn:(id)send{
    [self removeFromSuperview];
}

-(void)ComfirBtn:(id)send{
    
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
