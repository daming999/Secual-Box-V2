//
//  PassValueMethod.h
//  TemperatureControlBLE
//
//  Created by 黄文雨 on 2018/9/11.
//  Copyright © 2018年 wenyu. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PassValueMethod : NSObject
+(PassValueMethod *)shareInstance;

@property (nonatomic,copy) NSString *pRoomNameStr;

@property (nonatomic,assign) NSInteger passTag;
@property (nonatomic,copy) NSString *selectPhoneNumber;
@property (nonatomic,copy) NSString *watchPortraitStr;
@property (nonatomic,copy) NSString *checkFlowAndFeeSelectPhoneNum;
@property (nonatomic,assign) BOOL ApplyForFailure;
@property (nonatomic,copy) NSString *passCancelTime;
@property (nonatomic,assign) BOOL isRegistComplete;
@property (nonatomic,strong) NSMutableArray *FeeMutArr;
@property (nonatomic,assign) BOOL isKickedoff;
@property (nonatomic,copy) NSString *passAppVersion;
@property (nonatomic,assign) BOOL isEnterPositionExplainPage;
@property (nonatomic,assign) BOOL isAppNeedsUpdate;
@property (nonatomic,copy) NSString *displayAppVersionStr;
@property (nonatomic,assign) NSInteger updateTimerNum;
@property (nonatomic,assign) NSInteger ProgressValue;
@property (nonatomic,copy) NSString *PercentageStr;
@property (nonatomic,assign) BOOL IsConnectSocketFlag;
@property (nonatomic,assign) BOOL IsStepNumPage;
@property (nonatomic,assign) BOOL IsBleOnLine;
@property (nonatomic,assign) BOOL IsNoAllowSlider;
@property (nonatomic,assign) BOOL IsTestHeartRate;
@property (nonatomic,assign) BOOL IsAccountSetPage;
@property (nonatomic,strong) NSMutableArray *BleNameMutArr;
@end
