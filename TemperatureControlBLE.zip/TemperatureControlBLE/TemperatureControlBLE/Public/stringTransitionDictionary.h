//
//  stringTransitionDictionary.h
//  OldManHappy
//
//  Created by 徐清兰 on 2017/1/9.
//  Copyright © 2017年 何. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface stringTransitionDictionary : NSObject
+(NSMutableDictionary *)dictionaryWithJsonString:(NSString *)jsonString;
@end
