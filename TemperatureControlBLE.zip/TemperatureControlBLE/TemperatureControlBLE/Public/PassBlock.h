//
//  PassBlock.h
//  TemperatureControlBLE
//
//  Created by 黄文雨 on 2018/9/11.
//  Copyright © 2018年 wenyu. All rights reserved.
//

#import <Foundation/Foundation.h>
typedef void (^PassTemperatureValue)(NSString *Wendu);
typedef void (^ShowStartTime)();
typedef void (^ShowEndTime)();
typedef void (^ShowWendu)();
typedef void (^SelectPickerViewWendu)();
typedef void (^AlreadyFindBleGotoOtherPage)();

@interface PassBlock : NSObject
+(PassBlock *)shareInstance;

@property (nonatomic,copy) PassTemperatureValue PassTemperatureValueBlock;
@property (nonatomic,copy) ShowStartTime ShowStartTimeBlcok;
@property (nonatomic,copy) ShowEndTime ShowEndTimeBlock;
@property (nonatomic,copy) ShowWendu ShowWenduBlock;
@property (nonatomic,copy) SelectPickerViewWendu SelectPickerViewWenduBlock;
@property (nonatomic,copy) AlreadyFindBleGotoOtherPage AlreadyFindBleGotoOtherPageBlock;
@end
