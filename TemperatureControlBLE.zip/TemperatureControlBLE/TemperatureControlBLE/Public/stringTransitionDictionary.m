//
//  stringTransitionDictionary.m
//  OldManHappy
//
//  Created by 徐清兰 on 2017/1/9.
//  Copyright © 2017年 何. All rights reserved.
//

#import "stringTransitionDictionary.h"
#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
@implementation stringTransitionDictionary
+(NSMutableDictionary *)dictionaryWithJsonString:(NSString *)jsonString
{
    if (jsonString == nil) {
        return nil;
    }
    
    NSData *jsonData = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
    NSError *err;
    NSMutableDictionary *dic = [NSJSONSerialization JSONObjectWithData:jsonData
                                                        options:NSJSONReadingMutableContainers
                                                          error:&err];
    if(err) {
        NSLog(@"json解析失败：%@",err);
        return nil;
    }
    return dic;
}


@end
