//
//  PassBlock.m
//  TemperatureControlBLE
//
//  Created by 黄文雨 on 2018/9/11.
//  Copyright © 2018年 wenyu. All rights reserved.
//

#import "PassBlock.h"

@implementation PassBlock
static PassBlock *share = nil;
+(PassBlock *)shareInstance{
    if(share==nil){
        share = [[PassBlock alloc] init];
    }
    return share;
}
@end
