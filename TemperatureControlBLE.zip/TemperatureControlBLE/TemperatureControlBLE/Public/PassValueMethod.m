//
//  PassValueMethod.m
//  TemperatureControlBLE
//
//  Created by 黄文雨 on 2018/9/11.
//  Copyright © 2018年 wenyu. All rights reserved.
//

#import "PassValueMethod.h"

@implementation PassValueMethod
static PassValueMethod *share = nil;
+(PassValueMethod *)shareInstance{
    if(share==nil){
        share = [[PassValueMethod alloc] init];
    }
    return share;
}
@end
