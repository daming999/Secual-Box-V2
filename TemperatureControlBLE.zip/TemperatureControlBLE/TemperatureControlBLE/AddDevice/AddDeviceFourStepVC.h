//
//  AddDeviceFourStepVC.h
//  TemperatureControlBLE
//
//  Created by 黄文雨 on 2018/8/21.
//  Copyright © 2018年 wenyu. All rights reserved.
//

#import "AddDeviceViewController.h"

@interface AddDeviceFourStepVC : AddDeviceViewController

@end
