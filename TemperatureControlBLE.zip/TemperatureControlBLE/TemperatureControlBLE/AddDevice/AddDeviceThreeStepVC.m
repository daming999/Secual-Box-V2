//
//  AddDeviceThreeStepVC.m
//  TemperatureControlBLE
//
//  Created by 黄文雨 on 2018/8/21.
//  Copyright © 2018年 wenyu. All rights reserved.
//

#import "AddDeviceThreeStepVC.h"
#import "InvokHeadFile.pch"

@interface AddDeviceThreeStepVC ()
{
    NSTimer *BleScanTimer;
    UILabel *BleScanTipslb;
    UILabel *BleScanSmallTipslb;
    UIImageView *RunLoopImgView;
    float angle;
    NSTimer *checkoutBleScanTime;
    BOOL isAllowQuit;
    UIImageView *ImgV;
}

@end

@implementation AddDeviceThreeStepVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    angle = 0;
    self.BackBtn.hidden = NO;
    self.wendujiImg.hidden = YES;
    self.wendujiImg.image = [UIImage imageNamed:@"wenduji_blue3"];
    [self.NavRightBtn addTarget:self action:@selector(BtnAction:) forControlEvents:UIControlEventTouchUpInside];
    self.TipsLb.text = NSLocalizedString(@"Pairing is in progress\n The device is connected to smartphone\n Please wait a few seconds", nil);
    
    ImgV = [[UIImageView alloc] initWithFrame:CGRectMake((ScrWidth-120)/2, ScrHeight-150, 115, 100)];
    ImgV.image = [UIImage imageNamed:@"Loading.png"];
    [self.view addSubview:ImgV];
    [self rotateView:ImgV];
}

- (void)rotateView:(UIImageView *)view
{
    CABasicAnimation *rotationAnimation;
    rotationAnimation = [CABasicAnimation animationWithKeyPath:@"transform.rotation.z"];
    rotationAnimation.toValue = [NSNumber numberWithFloat:M_PI*2.0];
    rotationAnimation.duration = 1;
    rotationAnimation.repeatCount = HUGE_VALF;
    [view.layer addAnimation:rotationAnimation forKey:@"rotationAnimation"];
}

-(void)viewDidDisappear:(BOOL)animated{
    [ImgV.layer removeAllAnimations];//停止动画
}

-(void)BtnAction:(id)send{
    AddDeviceFourStepVC *device = [[AddDeviceFourStepVC alloc] init];
    [self.navigationController pushViewController:device animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
