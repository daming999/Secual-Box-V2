//
//  AddDeviceFourStepVC.m
//  TemperatureControlBLE
//
//  Created by 黄文雨 on 2018/8/21.
//  Copyright © 2018年 wenyu. All rights reserved.
//

#import "AddDeviceFourStepVC.h"
#import "InvokHeadFile.pch"
@interface AddDeviceFourStepVC ()
{
    UILabel *DeviceNameLb;
    UITextField *DeviceNameTf;
    UILabel *RoomLb;
}
@end

@implementation AddDeviceFourStepVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.BackBtn.hidden = NO;
    self.wendujiImg.image = [UIImage imageNamed:@"wenduji_blue3"];
    [self.NavRightBtn addTarget:self action:@selector(BtnAction:) forControlEvents:UIControlEventTouchUpInside];
    self.bigDevice.hidden = YES;
    self.TipsLb.hidden = YES;
    
    DeviceNameLb = [[UILabel alloc] initWithFrame:CGRectMake(20, 120, 60, 30)];
    DeviceNameLb.text = NSLocalizedString(@"Name", nil);
    [DeviceNameLb setTextColor:TextBlackColor];
    DeviceNameLb.font = [UIFont systemFontOfSize:15.0];
    [self.view addSubview:DeviceNameLb];
    
    DeviceNameTf = [[UITextField alloc] initWithFrame:CGRectMake(DeviceNameLb.frame.origin.x+60,DeviceNameLb.frame.origin.y, 200,35)];
    DeviceNameTf.borderStyle = UITextBorderStyleRoundedRect;
    DeviceNameTf.keyboardType = UIKeyboardTypeDefault;
    DeviceNameTf.autocorrectionType = UITextAutocorrectionTypeYes;
    DeviceNameTf.placeholder = NSLocalizedString(@"请输入设备名称", nil);
    DeviceNameTf.returnKeyType = UIReturnKeyDone;
    DeviceNameTf.clearButtonMode = UITextFieldViewModeWhileEditing;
    [DeviceNameTf setBackgroundColor:[UIColor whiteColor]];
    DeviceNameTf.delegate = self;
    [self.view addSubview:DeviceNameTf];
    
    RoomLb = [[UILabel alloc] initWithFrame:CGRectMake(20, DeviceNameLb.frame.origin.y + 60, 60, 30)];
    RoomLb.text = NSLocalizedString(@"Room", nil);
    [RoomLb setTextColor:TextBlackColor];
    RoomLb.font = [UIFont systemFontOfSize:15.0];
    [self.view addSubview:RoomLb];

}

-(void)BtnAction:(id)send{
    AddDeviceFiveStepVC *device = [[AddDeviceFiveStepVC alloc] init];
    [self.navigationController pushViewController:device animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
