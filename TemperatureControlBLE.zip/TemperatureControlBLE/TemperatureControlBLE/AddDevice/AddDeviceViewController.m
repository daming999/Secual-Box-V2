//
//  AddDeviceViewController.m
//  TemperatureControlBLE
//
//  Created by 黄文雨 on 2018/8/21.
//  Copyright © 2018年 wenyu. All rights reserved.
//

#import "AddDeviceViewController.h"
#import "InvokHeadFile.pch"
@interface AddDeviceViewController ()

@end

@implementation AddDeviceViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self.navigationController setNavigationBarHidden:YES animated:NO];
    [self LoadSubView];
}

-(void)LoadSubView{
    
//    self.BackBtn.hidden = YES;
//    UIButton *LoginBtn = [[UIButton alloc] initWithFrame:CGRectMake((ScrWidth-80)/2, 80, 80, 30)];
//    LoginBtn.backgroundColor = [UIColor redColor];
//    [LoginBtn addTarget:self action:@selector(LoginBtn:) forControlEvents:UIControlEventTouchUpInside];
//    [LoginBtn setTitle:NSLocalizedString(@"Login", nil) forState:UIControlStateNormal];
//    [self.view addSubview:LoginBtn];
    [UIApplication sharedApplication].applicationIconBadgeNumber = 0;
    CGFloat bigDeviceW = 300;
    CGFloat bigDeviceH = 200;
    CGFloat bigDevicejjH = ScrHeight *0.188;
    _bigDevice = [[UIImageView alloc] initWithFrame:CGRectMake((ScrWidth-bigDeviceW)/2, 100,bigDeviceW, bigDeviceH)];
    _bigDevice.image = [UIImage imageNamed:@"device_big"];
    [self.view addSubview:_bigDevice];
    
    CGFloat TipsLbjjH = ScrHeight *0.52;
    _TipsLb = [[UILabel alloc] initWithFrame:CGRectMake(10, TipsLbjjH, ScrWidth-20, 80)];
    _TipsLb.font = [UIFont systemFontOfSize:15.0];
    _TipsLb.textAlignment = UITextAlignmentLeft;
    _TipsLb.numberOfLines = 0;
    _TipsLb.text = NSLocalizedString(@"Activate teach-in mode\n To activate teach-in mode press an hold down the control if radiator themostat unti PAIR appears on the display", nil);
    _TipsLb.textColor = TextGaryColor;
    [self.view addSubview:_TipsLb];
    
    CGFloat wendujiImgjjH = ScrHeight *0.927;
    _wendujiImg = [[UIImageView alloc] initWithFrame:CGRectMake((ScrWidth-200)/2, wendujiImgjjH,200, 15)];
    _wendujiImg.image = [UIImage imageNamed:@"wenduji_blue"];
    [self.view addSubview:_wendujiImg];
    
    [self.NavRightBtn setImage:[UIImage imageNamed:@"sandian"] forState:UIControlStateNormal];
    [self.NavRightBtn addTarget:self action:@selector(BtnAction:) forControlEvents:UIControlEventTouchUpInside];
}

-(void)LoginBtn:(id)send{
    LoginViewController *Login = [[LoginViewController alloc] init];
    [self.navigationController pushViewController:Login animated:YES];
}

-(void)BtnAction:(id)send{
    AddDeviceSecondStepVC *Room = [[AddDeviceSecondStepVC alloc] init];
    [self.navigationController pushViewController:Room animated:YES];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
