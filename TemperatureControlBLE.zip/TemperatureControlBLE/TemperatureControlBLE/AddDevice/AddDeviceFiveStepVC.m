//
//  AddDeviceFiveStepVC.m
//  TemperatureControlBLE
//
//  Created by 黄文雨 on 2018/8/22.
//  Copyright © 2018年 wenyu. All rights reserved.
//

#import "AddDeviceFiveStepVC.h"

@interface AddDeviceFiveStepVC ()

@end

@implementation AddDeviceFiveStepVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self.wendujiImg setImage:[UIImage imageNamed:@"wenduji_blue4"]];
    self.TipsLb.text = NSLocalizedString(@"Teach in successful \n Teach in was successful \n Please connect all derices to a room first beforeadjusting the room configuration.", nil);
    [self.NavRightBtn addTarget:self action:@selector(BtnAction:) forControlEvents:UIControlEventTouchUpInside];
   
}

-(void)BtnAction:(id)send{
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
