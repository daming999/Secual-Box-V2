//
//  AddDeviceSecondStepVC.m
//  TemperatureControlBLE
//
//  Created by 黄文雨 on 2018/8/21.
//  Copyright © 2018年 wenyu. All rights reserved.
//

#import "AddDeviceSecondStepVC.h"
#import "InvokHeadFile.pch"

@interface AddDeviceSecondStepVC ()
{
    UITextField *PairCodeTf;
}
@end

@implementation AddDeviceSecondStepVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.BackBtn.hidden = NO;
    self.bigDevice.hidden = YES;
    self.wendujiImg.hidden = YES;
    self.wendujiImg.image = [UIImage imageNamed:@"wenduji_blue2"];
    
    //Please enter the four digits displayed on the radiator themostat
    CGFloat TipsLbjjH = ScrHeight *0.348;
    self.TipsLb.frame = CGRectMake(10,TipsLbjjH, ScrWidth-20, 60);
    self.TipsLb.text = NSLocalizedString(@"Please enter the four digits displayed on the radiator themostat", nil);
    [self.NavRightBtn addTarget:self action:@selector(BtnAction:) forControlEvents:UIControlEventTouchUpInside];
    
    UIButton *continueBtn = [[UIButton alloc] initWithFrame:CGRectMake((ScrWidth-120)/2, ScrHeight-100, 120, 30)];
    continueBtn.backgroundColor = [UIColor colorWithRed:178.0/255.0 green:179.0/255.0 blue:180.0/255.0 alpha:1.0];
    [continueBtn addTarget:self action:@selector(continueBtn:) forControlEvents:UIControlEventTouchUpInside];
    [continueBtn setTitle:NSLocalizedString(@"Continue", nil) forState:UIControlStateNormal];
    [self.view addSubview:continueBtn];
    
    CGFloat pairCodeTfjjH = ScrHeight *0.461;
    PairCodeTf = [[UITextField alloc] initWithFrame:CGRectMake((ScrWidth-150)/2,pairCodeTfjjH, 150,35)];
    PairCodeTf.borderStyle = UITextBorderStyleRoundedRect;
    PairCodeTf.keyboardType = UIKeyboardTypeDefault;
    PairCodeTf.autocorrectionType = UITextAutocorrectionTypeYes;
    PairCodeTf.placeholder = NSLocalizedString(@"请输入配对码", nil);
    PairCodeTf.returnKeyType = UIReturnKeyDone;
    PairCodeTf.clearButtonMode = UITextFieldViewModeWhileEditing;
    [PairCodeTf setBackgroundColor:[UIColor whiteColor]];
    PairCodeTf.delegate = self;
    [self.view addSubview:PairCodeTf];

}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    
    if (textField == PairCodeTf) {
        //这里的if时候为了获取删除操作,如果没有次if会造成当达到字数限制后删除键也不能使用的后果.
        if (range.length == 1 && string.length == 0) {
            NSLog(@"");
            return YES;
        }
        //so easy
        else if (PairCodeTf.text.length >= 8) {
            PairCodeTf.text = [textField.text substringToIndex:8];
             NSLog(@"");
            return NO;
        }
    }
    return YES;
}

-(void)continueBtn:(id)send{
    AddDeviceThreeStepVC *device = [[AddDeviceThreeStepVC alloc] init];
    [self.navigationController pushViewController:device animated:YES];
}
-(void)BtnAction:(id)send{
    AddDeviceThreeStepVC *device = [[AddDeviceThreeStepVC alloc] init];
    [self.navigationController pushViewController:device animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
