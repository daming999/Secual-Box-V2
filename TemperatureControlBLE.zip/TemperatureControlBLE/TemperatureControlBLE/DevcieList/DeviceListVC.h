//
//  DeviceListVC.h
//  TemperatureControlBLE
//
//  Created by 黄文雨 on 2018/8/23.
//  Copyright © 2018年 wenyu. All rights reserved.
//

#import "TCBBaseVC.h"

@interface DeviceListVC : TCBBaseVC<UITableViewDelegate,UITableViewDataSource>

@end
