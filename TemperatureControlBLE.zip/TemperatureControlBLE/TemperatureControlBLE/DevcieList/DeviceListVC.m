//
//  DeviceListVC.m
//  TemperatureControlBLE
//
//  Created by 黄文雨 on 2018/8/23.
//  Copyright © 2018年 wenyu. All rights reserved.
//

#import "DeviceListVC.h"
#import "InvokHeadFile.pch"

@interface DeviceListVC ()
@property (nonatomic,strong) UITableView *TableViewList;

@end

@implementation DeviceListVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.TitleLb.text = NSLocalizedString(@"设备列表", nil);
    [self LoadSubView];
}

-(void)LoadSubView
{
    _TableViewList = [[UITableView alloc] initWithFrame:CGRectMake(0, 66, ScrWidth, ScrHeight) style:UITableViewStyleGrouped];
    _TableViewList.separatorStyle = UITableViewStyleGrouped;
    [_TableViewList setBackgroundColor:[UIColor whiteColor]];
    _TableViewList.separatorColor = [UIColor whiteColor];
    _TableViewList.showsVerticalScrollIndicator = YES;
    _TableViewList.scrollEnabled = YES;
    _TableViewList.delegate = self;
    _TableViewList.dataSource = self;
    _TableViewList.estimatedRowHeight = 0;
    if (@available(iOS 11.0, *)) {
        _TableViewList.estimatedSectionHeaderHeight = 0;
        _TableViewList.estimatedSectionFooterHeight = 0;
    }
    [self.view addSubview:_TableViewList];
    
    
    if ([_TableViewList respondsToSelector:@selector(setSeparatorInset:)]) {
        [_TableViewList setSeparatorInset:UIEdgeInsetsZero];
    }
    if ([_TableViewList respondsToSelector:@selector(setLayoutMargins:)]) {
        [_TableViewList setLayoutMargins:UIEdgeInsetsZero];
    }
    
    NSLog(@"=========蓝牙设备数组======= %@",[PassValueMethod shareInstance].BleNameMutArr);
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([cell respondsToSelector:@selector(setSeparatorInset:)])
    {
        [cell setSeparatorInset:UIEdgeInsetsZero];
    }
    
    if ([cell respondsToSelector:@selector(setLayoutMargins:)])
    {
        [cell setLayoutMargins:UIEdgeInsetsZero];
    }
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView;
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [PassValueMethod shareInstance].BleNameMutArr.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 50;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (section == 0) {
        return 0.0001;
    }else{
        return 10;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *tableCellIdentifier = @"DeviceListCell";
    DeviceListCell *cell = (DeviceListCell *)[tableView dequeueReusableCellWithIdentifier:tableCellIdentifier];
    if(cell == nil){
        NSArray *nib = [[NSBundle mainBundle]loadNibNamed:@"DeviceListCell" owner:self options:nil];
        for(id oneObject in nib){
            if([oneObject isKindOfClass:[DeviceListCell class]]){
                cell = (DeviceListCell *)oneObject;
                cell.backgroundColor = [UIColor whiteColor];
                cell.DeviceNameLb.text = [NSString stringWithFormat:@"%@",[[PassValueMethod shareInstance].BleNameMutArr objectAtIndex:[indexPath row]]];
            }
        }
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([indexPath section]==0)
    {
        TemperatureSetVC *Set = [[TemperatureSetVC alloc] init];
        [self.navigationController pushViewController:Set animated:YES];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
