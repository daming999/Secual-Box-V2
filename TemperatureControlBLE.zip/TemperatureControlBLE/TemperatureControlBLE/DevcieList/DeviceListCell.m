//
//  DeviceListCell.m
//  TemperatureControlBLE
//
//  Created by 黄文雨 on 2018/8/23.
//  Copyright © 2018年 wenyu. All rights reserved.
//

#import "DeviceListCell.h"
#import "InvokHeadFile.pch"

@implementation DeviceListCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    self.DeviceNameLb.textColor = TextGaryColor;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
