//
//  DeviceListCell.h
//  TemperatureControlBLE
//
//  Created by 黄文雨 on 2018/8/23.
//  Copyright © 2018年 wenyu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DeviceListCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *DeviceNameLb;

@end
