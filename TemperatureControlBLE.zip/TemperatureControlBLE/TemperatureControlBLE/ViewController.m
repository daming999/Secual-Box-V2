//
//  ViewController.m
//  TemperatureControlBLE
//
//  Created by 黄文雨 on 2018/8/20.
//  Copyright © 2018年 wenyu. All rights reserved.
//

#import "ViewController.h"
#import "InvokHeadFile.pch"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    UIButton *Btn = [[UIButton alloc] initWithFrame:CGRectMake((ScrWidth-80)/2, 80, 80, 30)];
    Btn.backgroundColor = [UIColor redColor];
    [Btn addTarget:self action:@selector(BtnAction:) forControlEvents:UIControlEventTouchUpInside];
    [Btn setTitle:@"跳转" forState:UIControlStateNormal];
    [self.view addSubview:Btn];
}

-(void)BtnAction:(id)sender{
  
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
