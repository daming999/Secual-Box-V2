//
//  TemperatureSetVC.m
//  TemperatureControlBLE
//
//  Created by 黄文雨 on 2018/8/22.
//  Copyright © 2018年 wenyu. All rights reserved.
//

#import "TemperatureSetVC.h"
#import "InvokHeadFile.pch"

@interface TemperatureSetVC ()
{
    UIButton *AutoBtn;
    UIButton *ManualBtn;
    UIButton *BoostBtn;
    UIButton *ComfortBtn;
    UIButton *EcoBtn;
    NSString *RoomNameStr;
    UILabel *TemperatureValueLb;
}
@property (strong, nonatomic) CircleIndicatorView *circleIndicatorView;
@end

@implementation TemperatureSetVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self.BackBtn setImage:[UIImage imageNamed:@"menu"] forState:UIControlStateNormal];
    self.BackBtn.frame = CGRectMake(5, 25, 30, 30);
    
    RoomNameStr = [PassValueMethod shareInstance].pRoomNameStr;
    self.TitleLb.text = NSLocalizedString(RoomNameStr, nil);
    [self LoadSubView];
    
    [PassBlock shareInstance].PassTemperatureValueBlock = ^(NSString *wendu){
        TemperatureValueLb.text = wendu;
        NSLog(@"");
    };
}

-(void)LoadSubView
{
    //电池
    CGFloat BtnWH = 50;
    CGFloat BtnjjH = ScrHeight *0.188;
    CGFloat BtnjjW = (ScrWidth-(BtnWH*5))/6;
    UIButton *BatteryBtn = [[UIButton alloc] initWithFrame:CGRectMake(BtnjjW, BtnjjH, BtnWH, BtnWH)];
    BatteryBtn.tag = 100;
    [BatteryBtn setImage:[UIImage imageNamed:@"dianchi_low"] forState:UIControlStateNormal];
    [BatteryBtn addTarget:self action:@selector(SetModelBtnAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:BatteryBtn];
    
    //开窗
    UIButton *WindowsBtn = [[UIButton alloc] initWithFrame:CGRectMake(BtnjjW*2+BtnWH, BtnjjH, BtnWH, BtnWH)];
    WindowsBtn.tag = 200;
    [WindowsBtn setImage:[UIImage imageNamed:@"windows_low"] forState:UIControlStateNormal];
    [WindowsBtn addTarget:self action:@selector(SetModelBtnAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:WindowsBtn];
    
    //飞行
    UIButton *FlightBtn = [[UIButton alloc] initWithFrame:CGRectMake(BtnWH*2+BtnjjW*3, BtnjjH, BtnWH, BtnWH)];
    FlightBtn.tag = 300;
    [FlightBtn setImage:[UIImage imageNamed:@"feiji_low"] forState:UIControlStateNormal];
    [FlightBtn addTarget:self action:@selector(SetModelBtnAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:FlightBtn];
    
    //蓝牙
    UIButton *BleBtn = [[UIButton alloc] initWithFrame:CGRectMake(BtnWH*3+BtnjjW*4, BtnjjH, BtnWH, BtnWH)];
    BleBtn.tag = 400;
    [BleBtn setImage:[UIImage imageNamed:@"ble_low"] forState:UIControlStateNormal];
    [BleBtn addTarget:self action:@selector(SetModelBtnAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:BleBtn];
    
    //加锁
    UIButton *LockBtn = [[UIButton alloc] initWithFrame:CGRectMake(BtnWH*4+BtnjjW*5, BtnjjH, BtnWH, BtnWH)];
    LockBtn.tag = 500;
    [LockBtn setImage:[UIImage imageNamed:@"lock_low"] forState:UIControlStateNormal];
    [LockBtn addTarget:self action:@selector(SetModelBtnAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:LockBtn];
    
    //温度值
    CGFloat TvLbH = ScrHeight *0.262;
    TemperatureValueLb = [[UILabel alloc] initWithFrame:CGRectMake((ScrWidth-150)/2, TvLbH, 150, 150)];
    TemperatureValueLb.text = @"50°C";
    TemperatureValueLb.font = [UIFont systemFontOfSize:60.0];
    TemperatureValueLb.textAlignment = UITextAlignmentCenter;
    TemperatureValueLb.textColor = TextBlueColor;
   
//    //刻度值
//    CGFloat scaleViewH = 180;
//    UIView *scaleView = [[UIView alloc] initWithFrame:CGRectMake(0, TemperatureValueLb.frame.origin.y+150, ScrWidth, scaleViewH)];
//    [scaleView setBackgroundColor:[UIColor clearColor]];
//    [self.view addSubview:scaleView];
    
    BOOL *IsIphone6 = ScrWidth > 320;
    //圆形
    self.circleIndicatorView = [[CircleIndicatorView alloc] init];
    self.circleIndicatorView.frame = CGRectMake(50, TemperatureValueLb.frame.origin.y+(IsIphone6?60:30),  ScrWidth-100, 300);
    self.circleIndicatorView.minValue = 0;
    self.circleIndicatorView.maxValue = 40;
    self.circleIndicatorView.innerAnnulusValueToShowArray = @[@0, @10, @20, @30, @40];
    self.circleIndicatorView.backgroundColor = [UIColor whiteColor];
    self.circleIndicatorView.indicatorValue = 15;
    [self.view addSubview:self.circleIndicatorView];
    [self.view  addSubview:TemperatureValueLb];
    self.circleIndicatorView.minusBlock = ^{
        
        NSLog(@"点击了 -");
        self.circleIndicatorView.indicatorValue -= 1;
        NSLog(@"这里是减法多少 = %d",self.circleIndicatorView.indicatorValue);
        
        NSString *wendu = [NSString stringWithFormat:@"%zd°C",self.circleIndicatorView.indicatorValue];
        
        if([PassBlock shareInstance].PassTemperatureValueBlock){
            [PassBlock shareInstance].PassTemperatureValueBlock(wendu);
        }
    };
    self.circleIndicatorView.addBlock = ^{
        
        NSLog(@"点击了 +");
        self.circleIndicatorView.indicatorValue += 1;
         NSLog(@"这里加法是多少 = %d",self.circleIndicatorView.indicatorValue);
        
        NSString *wendu = [NSString stringWithFormat:@"%zd°C",self.circleIndicatorView.indicatorValue];
        
        if([PassBlock shareInstance].PassTemperatureValueBlock){
            [PassBlock shareInstance].PassTemperatureValueBlock(wendu);
        }
    };

    
    
    //最近的温度显示值
    CGFloat CurrentWDLbjjH = ScrHeight *0.75;
    UILabel *CurrentwenduValueLb = [[UILabel alloc] initWithFrame:CGRectMake(0, CurrentWDLbjjH, ScrWidth, 35)];
    CurrentwenduValueLb.text = @"Cuurent Temperature 25°C";
    CurrentwenduValueLb.font = [UIFont systemFontOfSize:15.0];
    CurrentwenduValueLb.textAlignment = UITextAlignmentCenter;
    CurrentwenduValueLb.textColor = TextGaryColor;
    [self.view  addSubview:CurrentwenduValueLb];
    
    //设置温度Img
    CGFloat controlImgW = ScrWidth-10;
    CGFloat controlImgH = 30;
//    UIView *controlView = [[UIImageView alloc] initWithFrame:CGRectMake((ScrWidth-controlImgW)/2, ScrHeight-100, controlImgW, controlImgH)];
//    [controlView setBackgroundColor:[UIColor clearColor]];
//    [self.view addSubview:controlView];
  
    CGFloat controlImgVjjH = ScrHeight *0.846;
    UIImageView *controlImgV = [[UIImageView alloc] initWithFrame:CGRectMake(0, controlImgVjjH, controlImgW, controlImgH)];
    controlImgV.image = [UIImage imageNamed:@"waikuang"];
    [self.view addSubview:controlImgV];
  
    //Auto
    CGFloat SetWenduBtnW = controlImgW/5;
    AutoBtn = [[UIButton alloc] initWithFrame:CGRectMake(5, controlImgV.frame.origin.y-(SetWenduBtnW-controlImgH)/2, SetWenduBtnW, SetWenduBtnW)];
    AutoBtn.tag = 100;
    AutoBtn.titleLabel.font = [UIFont systemFontOfSize: 15.0];
    AutoBtn.backgroundColor = BackGroudClearColor;
    AutoBtn.layer.cornerRadius = SetWenduBtnW/2;
    [AutoBtn setTitle:NSLocalizedString(@"Auto", nil) forState:UIControlStateNormal];
    [AutoBtn setTitleColor:TextGaryColor forState:UIControlStateNormal];
    [AutoBtn addTarget:self action:@selector(setWenduBtnAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:AutoBtn];
    
    
    //Manual
    ManualBtn = [[UIButton alloc] initWithFrame:CGRectMake(5+SetWenduBtnW, controlImgV.frame.origin.y-(SetWenduBtnW-controlImgH)/2, SetWenduBtnW, SetWenduBtnW)];
    ManualBtn.titleLabel.font = [UIFont systemFontOfSize: 15.0];
    ManualBtn.tag = 200;
    ManualBtn.backgroundColor = BackGroudClearColor;
    ManualBtn.layer.cornerRadius = SetWenduBtnW/2;
    [ManualBtn setTitle:NSLocalizedString(@"Manual", nil) forState:UIControlStateNormal];
    [ManualBtn setTitleColor:TextGaryColor forState:UIControlStateNormal];
    [ManualBtn addTarget:self action:@selector(setWenduBtnAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:ManualBtn];
    
    //Boost
    BoostBtn = [[UIButton alloc] initWithFrame:CGRectMake(5+SetWenduBtnW*2, controlImgV.frame.origin.y-(SetWenduBtnW-controlImgH)/2, SetWenduBtnW, SetWenduBtnW)];
    BoostBtn.titleLabel.font = [UIFont systemFontOfSize:15.0];
    BoostBtn.tag = 300;
    BoostBtn.layer.cornerRadius = SetWenduBtnW/2;
    BoostBtn.backgroundColor = BackGroundBlueColor;
    [BoostBtn setTitle:NSLocalizedString(@"Boost", nil) forState:UIControlStateNormal];
    [BoostBtn setTitleColor:TextWhiteColor forState:UIControlStateNormal];
    [BoostBtn addTarget:self action:@selector(setWenduBtnAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:BoostBtn];
    
    //Comfort
    ComfortBtn = [[UIButton alloc] initWithFrame:CGRectMake(5+SetWenduBtnW*3, controlImgV.frame.origin.y-(SetWenduBtnW-controlImgH)/2, SetWenduBtnW, SetWenduBtnW)];
    ComfortBtn.titleLabel.font = [UIFont systemFontOfSize:15.0];
    ComfortBtn.tag = 400;
    ComfortBtn.backgroundColor = BackGroudClearColor;
    ComfortBtn.layer.cornerRadius = SetWenduBtnW/2;
    [ComfortBtn setTitle:NSLocalizedString(@"Comfort", nil) forState:UIControlStateNormal];
    [ComfortBtn setTitleColor:TextGaryColor forState:UIControlStateNormal];
    [ComfortBtn addTarget:self action:@selector(setWenduBtnAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:ComfortBtn];
    
    //Eco
    EcoBtn = [[UIButton alloc] initWithFrame:CGRectMake(5+SetWenduBtnW*4, controlImgV.frame.origin.y-(SetWenduBtnW-controlImgH)/2, SetWenduBtnW, SetWenduBtnW)];
    EcoBtn.titleLabel.font = [UIFont systemFontOfSize:15.0];
    EcoBtn.backgroundColor = BackGroudClearColor;
    EcoBtn.tag = 500;
    EcoBtn.layer.cornerRadius = SetWenduBtnW/2;
    [EcoBtn setTitle:NSLocalizedString(@"Eco", nil) forState:UIControlStateNormal];
    [EcoBtn setTitleColor:TextGaryColor forState:UIControlStateNormal];
    [EcoBtn addTarget:self action:@selector(setWenduBtnAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view  addSubview:EcoBtn];
}

-(void)setWenduBtnAction:(UIButton *)send
{
    NSLog(@"----------------------");
    if (send.tag==100)
    {
//        AutoBtn.backgroundColor = BackGroundBlueColor;
//        ManualBtn.backgroundColor = BackGroudClearColor;
//        BoostBtn.backgroundColor = BackGroudClearColor;
//        ComfortBtn.backgroundColor = BackGroudClearColor;
//        EcoBtn.backgroundColor = BackGroudClearColor;
    }
    else if (send.tag==200){
        
//        AutoBtn.backgroundColor = BackGroudClearColor;
//        ManualBtn.backgroundColor = BackGroundBlueColor;
//        BoostBtn.backgroundColor = BackGroudClearColor;
//        ComfortBtn.backgroundColor = BackGroudClearColor;
//        EcoBtn.backgroundColor = BackGroudClearColor;
    }
    else if (send.tag==300){
        
        AutoBtn.backgroundColor = BackGroudClearColor;
        ManualBtn.backgroundColor = BackGroudClearColor;
        BoostBtn.backgroundColor = BackGroundBlueColor;
        ComfortBtn.backgroundColor = BackGroudClearColor;
        EcoBtn.backgroundColor = BackGroudClearColor;
    }
    else if (send.tag==400){
        
//        AutoBtn.backgroundColor = BackGroudClearColor;
//        ManualBtn.backgroundColor = BackGroudClearColor;
//        BoostBtn.backgroundColor = BackGroudClearColor;
//        ComfortBtn.backgroundColor = BackGroundBlueColor;
//        EcoBtn.backgroundColor = BackGroudClearColor;
    }
    else if (send.tag==500){
        
//        AutoBtn.backgroundColor = BackGroudClearColor;
//        ManualBtn.backgroundColor = BackGroudClearColor;
//        BoostBtn.backgroundColor = BackGroudClearColor;
//        ComfortBtn.backgroundColor = BackGroudClearColor;
//        EcoBtn.backgroundColor = BackGroundBlueColor;
    }
}

-(void)SetModelBtnAction:(UIButton *)send{
    
    if(send.tag==100){
        
    }
    else if (send.tag==200){
        
    }
    else if (send.tag==300){
        
    }
    else if (send.tag==400){
        
    }
    else if (send.tag==500){
        
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
