//
//  SetCell.m
//  TemperatureControlBLE
//
//  Created by 黄文雨 on 2018/9/10.
//  Copyright © 2018年 wenyu. All rights reserved.
//

#import "SetCell.h"
#import "InvokHeadFile.pch"

@implementation SetCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    self.NameLb.textColor = TextGaryColor;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
