//
//  SetCell.h
//  TemperatureControlBLE
//
//  Created by 黄文雨 on 2018/9/10.
//  Copyright © 2018年 wenyu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SetCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *NameLb;

@end
