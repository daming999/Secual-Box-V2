//
//  SetViewController.m
//  TemperatureControlBLE
//
//  Created by 黄文雨 on 2018/9/10.
//  Copyright © 2018年 wenyu. All rights reserved.
//

#import "SetViewController.h"
#import "InvokHeadFile.pch"

@interface SetViewController ()
@property (nonatomic,strong) UITableView *TableViewList;
@end

@implementation SetViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.TitleLb.text = NSLocalizedString(@"房间", nil);
    [self LoadSubView];
    
    [self.NavRightBtn addTarget:self action:@selector(RightBtn:) forControlEvents:UIControlEventTouchUpInside];
}

-(void)RightBtn:(id)send{
    
}

-(void)LoadSubView
{
    CGFloat BackViewH = ScrHeight-66;
    UIView *BackView = [[UIView alloc] initWithFrame:CGRectMake(2, 66, ScrWidth-4, BackViewH)];
    BackView.layer.borderWidth = 0.8;
    BackView.layer.borderColor = [UIColor lightGrayColor].CGColor;
    BackView.layer.cornerRadius = 5;
    [BackView setBackgroundColor:[UIColor clearColor]];
    [self.view addSubview:BackView];
    
    _TableViewList = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, ScrWidth-4, BackViewH) style:UITableViewStyleGrouped];
    _TableViewList.separatorStyle = UITableViewStyleGrouped;
    [_TableViewList setBackgroundColor:[UIColor whiteColor]];
    _TableViewList.separatorColor = [UIColor whiteColor];
    _TableViewList.showsVerticalScrollIndicator = YES;
    _TableViewList.scrollEnabled = YES;
    _TableViewList.delegate = self;
    _TableViewList.dataSource = self;
    _TableViewList.estimatedRowHeight = 0;
    if (@available(iOS 11.0, *)) {
        _TableViewList.estimatedSectionHeaderHeight = 0;
        _TableViewList.estimatedSectionFooterHeight = 0;
    }
    [BackView addSubview:_TableViewList];
    
    
    if ([_TableViewList respondsToSelector:@selector(setSeparatorInset:)]) {
        [_TableViewList setSeparatorInset:UIEdgeInsetsZero];
    }
    if ([_TableViewList respondsToSelector:@selector(setLayoutMargins:)]) {
        [_TableViewList setLayoutMargins:UIEdgeInsetsZero];
    }

    [self.NavRightBtn addTarget:self action:@selector(RightBtn:) forControlEvents:UIControlEventTouchUpInside];
}


- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([cell respondsToSelector:@selector(setSeparatorInset:)])
    {
        [cell setSeparatorInset:UIEdgeInsetsZero];
    }
    
    if ([cell respondsToSelector:@selector(setLayoutMargins:)])
    {
        [cell setLayoutMargins:UIEdgeInsetsZero];
    }
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView;
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 9;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 58;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (section == 0) {
        return 0.0001;
    }else{
        return 10;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *tableCellIdentifier = @"SetCell";
    SetCell *cell = (SetCell *)[tableView dequeueReusableCellWithIdentifier:tableCellIdentifier];
    if(cell == nil){
        NSArray *nib = [[NSBundle mainBundle]loadNibNamed:@"SetCell" owner:self options:nil];
        for(id oneObject in nib){
            if([oneObject isKindOfClass:[SetCell class]]){
                cell = (SetCell *)oneObject;
                cell.backgroundColor = [UIColor whiteColor];
                
                if(indexPath.row==0){
                    cell.NameLb.text = NSLocalizedString(@"Week Programming", nil);
                }
                else if (indexPath.row==1){
                    cell.NameLb.text = NSLocalizedString(@"Holiday mode", nil);
                }
                else if (indexPath.row==2){
                    cell.NameLb.text = NSLocalizedString(@"Energy saving and comfortable setting", nil);
                }
                else if (indexPath.row==3){
                    cell.NameLb.text = NSLocalizedString(@"Open the window function", nil);
                }
                else if (indexPath.row==4){
                    cell.NameLb.text = NSLocalizedString(@"Set the device lock", nil);
                }
                else if (indexPath.row==5){
                    cell.NameLb.text = NSLocalizedString(@"Temperature offset settings", nil);
                }
                else if (indexPath.row==6){
                    cell.NameLb.text = NSLocalizedString(@"Change device name", nil);
                }
                else if (indexPath.row==7){
                    cell.NameLb.text = NSLocalizedString(@"Delete device", nil);
                }
                else if (indexPath.row==8){
                    cell.NameLb.text = NSLocalizedString(@"Update firmware", nil);
                }
                
                
//
//                UIButton *LongPressBtn=[UIButton buttonWithType:UIButtonTypeRoundedRect];
//                [LongPressBtn setFrame:CGRectMake(0, 0, ScrWidth, 50)];
//                [LongPressBtn setBackgroundColor:[UIColor clearColor]];
//                [LongPressBtn addTarget:self action:@selector(ShorPressAction:) forControlEvents:UIControlEventTouchUpInside];
//                //button长按事件
//                UILongPressGestureRecognizer *longPress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(btnLong:)];
//                longPress.minimumPressDuration = 5; //定义按的时间
//                [LongPressBtn addGestureRecognizer:longPress];
//
//                [cell addSubview:LongPressBtn];
            }
        }
    }
    return cell;
}

-(void)ShorPressAction:(id)send{
    
    DeviceListVC *List = [[DeviceListVC alloc] init];
    [self.navigationController pushViewController:List animated:YES];
}

-(void)btnLong:(UILongPressGestureRecognizer *)gestureRecognizer
{
    if ([gestureRecognizer state] == UIGestureRecognizerStateBegan) {
        
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"消息" message:@"您确定修改房间信息吗？" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"修改", nil];
        [alert show];
    }
}

//监听点击事件 代理方法
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    NSString *btnTitle = [alertView buttonTitleAtIndex:buttonIndex];
    if ([btnTitle isEqualToString:@"取消"]) {
        NSLog(@"你点击了取消");
    }
    else if ([btnTitle isEqualToString:@"修改"] )
    {
        EditRoomInfoVC *Edit = [[EditRoomInfoVC alloc] init];
        [self.navigationController pushViewController:Edit animated:YES];
    }
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.row==0){
        
    }
    else if (indexPath.row==1){
        
    }
    else if (indexPath.row==2){
        
    }
    else if (indexPath.row==3){
        
    }
    else if (indexPath.row==4){
        
    }
    else if (indexPath.row==5){
        
    }
    else if (indexPath.row==6){
        
    }
    else if (indexPath.row==7){
        
    }
    else if (indexPath.row==8){
        
    }
    NSLog(@"===========================设置 99999999999999999999======================================");
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
