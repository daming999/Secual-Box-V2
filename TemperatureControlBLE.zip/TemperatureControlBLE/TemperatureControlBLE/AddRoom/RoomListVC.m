//
//  RoomListVC.m
//  TemperatureControlBLE
//
//  Created by 黄文雨 on 2018/8/23.
//  Copyright © 2018年 wenyu. All rights reserved.
//

#import "RoomListVC.h"
#import "InvokHeadFile.pch"

@interface RoomListVC ()<UITableViewDataSource,UITableViewDelegate>
@property (nonatomic,strong) UITableView *TableViewList;
@end

@implementation RoomListVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self.navigationController setNavigationBarHidden:YES animated:NO];
    [self.TitleLb setText:NSLocalizedString(@"房间列表", nil)];
    [self LoadSubView];
    
}

-(void)LoadSubView
{
    CGFloat BackViewH = ScrHeight-200;
    UIView *BackView = [[UIView alloc] initWithFrame:CGRectMake(2, 66, ScrWidth-4, BackViewH)];
    BackView.layer.borderWidth = 0.8;
    BackView.layer.borderColor = [UIColor lightGrayColor].CGColor;
    BackView.layer.cornerRadius = 5;
    [BackView setBackgroundColor:[UIColor clearColor]];
    [self.view addSubview:BackView];
    
    _TableViewList = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, ScrWidth-4, BackViewH) style:UITableViewStyleGrouped];
    _TableViewList.separatorStyle = UITableViewStyleGrouped;
    [_TableViewList setBackgroundColor:[UIColor whiteColor]];
    _TableViewList.separatorColor = [UIColor whiteColor];
    _TableViewList.showsVerticalScrollIndicator = YES;
    _TableViewList.scrollEnabled = YES;
    _TableViewList.delegate = self;
    _TableViewList.dataSource = self;
    _TableViewList.estimatedRowHeight = 0;
    if (@available(iOS 11.0, *)) {
        _TableViewList.estimatedSectionHeaderHeight = 0;
        _TableViewList.estimatedSectionFooterHeight = 0;
    }
    [BackView addSubview:_TableViewList];
    
    if ([_TableViewList respondsToSelector:@selector(setSeparatorInset:)]) {
        [_TableViewList setSeparatorInset:UIEdgeInsetsZero];
    }
    if ([_TableViewList respondsToSelector:@selector(setLayoutMargins:)]) {
        [_TableViewList setLayoutMargins:UIEdgeInsetsZero];
    }
    
    UIButton *AddDeviceBtn = [[UIButton alloc] initWithFrame:CGRectMake((ScrWidth-120)/2, ScrHeight-125, 120, 30)];
    AddDeviceBtn.backgroundColor = [UIColor colorWithRed:178.0/255.0 green:179.0/255.0 blue:180.0/255.0 alpha:1.0];
    [AddDeviceBtn addTarget:self action:@selector(AddDeviceBtn:) forControlEvents:UIControlEventTouchUpInside];
    [AddDeviceBtn setTitle:NSLocalizedString(@"Add Device", nil) forState:UIControlStateNormal];	
    AddDeviceBtn.layer.cornerRadius = 5;
    AddDeviceBtn.layer.masksToBounds = YES;
    [self.view addSubview:AddDeviceBtn];
    
    UIButton *OtherBtn = [[UIButton alloc] initWithFrame:CGRectMake((ScrWidth-120)/2, AddDeviceBtn.frame.origin.y+40, 120, 30)];
    OtherBtn.backgroundColor = [UIColor colorWithRed:178.0/255.0 green:179.0/255.0 blue:180.0/255.0 alpha:1.0];
    [OtherBtn addTarget:self action:@selector(OtherBtn:) forControlEvents:UIControlEventTouchUpInside];
    [OtherBtn setTitle:NSLocalizedString(@"Add Other", nil) forState:UIControlStateNormal];
    OtherBtn.layer.cornerRadius = 5;
    OtherBtn.layer.masksToBounds = YES;
    [self.view addSubview:OtherBtn];
    
    UIButton *sendBtn = [[UIButton alloc] initWithFrame:CGRectMake((ScrWidth-120)/2, OtherBtn.frame.origin.y+40, 120, 30)];
    sendBtn.backgroundColor = [UIColor colorWithRed:178.0/255.0 green:179.0/255.0 blue:180.0/255.0 alpha:1.0];
    [sendBtn addTarget:self action:@selector(SendBtn:) forControlEvents:UIControlEventTouchUpInside];
    [sendBtn setTitle:NSLocalizedString(@"Send", nil) forState:UIControlStateNormal];
    sendBtn.layer.cornerRadius = 5;
    sendBtn.layer.masksToBounds = YES;
    [self.view addSubview:sendBtn];
    
    [self.NavRightBtn addTarget:self action:@selector(RightBtn:) forControlEvents:UIControlEventTouchUpInside];
}

-(void)RightBtn:(id)send
{
    WeekProgrammeVC *WeekVC = [[WeekProgrammeVC alloc] init];
    [self.navigationController pushViewController:WeekVC animated:YES];
}

-(void)OtherBtn:(id)send
{
    
//    RenameView *SetWendu = [[RenameView alloc] initWithFrame:CGRectMake(0, 0, ScrWidth, ScrHeight)];
//    SetWendu.backgroundColor = [UIColor colorWithWhite:0 alpha:0.5];
//    [self.view addSubview:SetWendu];
    
//    SetViewController *Set = [[SetViewController alloc] init];
//    [self.navigationController pushViewController:Set animated:YES];
    
    [PassValueMethod shareInstance].BleNameMutArr = nil; //清空数组
    NSLog(@"====清空单利模式的数组=====%@",[PassValueMethod shareInstance].BleNameMutArr );
    
    ScanBleVC *ScanBle = [[ScanBleVC alloc] init];
    [self.navigationController pushViewController:ScanBle animated:YES];
}

-(void)SendBtn:(id)send{
    
    [BleSharedMethod sharedInstance].cbPeripheral.delegate = self;
    Byte byte[] = {0XEB};
    NSData *xmlData = [[NSData alloc] initWithBytes:byte length:1];
    [[BleSharedMethod sharedInstance].cbPeripheral writeValue:xmlData forCharacteristic:[BleSharedMethod sharedInstance].WriteCharacteracteristic type:CBCharacteristicWriteWithResponse];
    NSLog(@"外围: = %@",[BleSharedMethod sharedInstance].cbPeripheral);
    NSLog(@"特征: = %@",[BleSharedMethod sharedInstance].WriteCharacteracteristic);
}

-(void)AddDeviceBtn:(id)send{
    AddDeviceViewController *Device = [[AddDeviceViewController alloc] init];
    [self.navigationController pushViewController:Device animated:YES];
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([cell respondsToSelector:@selector(setSeparatorInset:)])
    {
        [cell setSeparatorInset:UIEdgeInsetsZero];
    }
    
    if ([cell respondsToSelector:@selector(setLayoutMargins:)])
    {
        [cell setLayoutMargins:UIEdgeInsetsZero];
    }
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView;
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 15;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 50;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (section == 0) {
        return 0.0001;
    }else{
        return 10;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *tableCellIdentifier = @"RoomCell";
    RoomCell *cell = (RoomCell *)[tableView dequeueReusableCellWithIdentifier:tableCellIdentifier];
    if(cell == nil){
        NSArray *nib = [[NSBundle mainBundle]loadNibNamed:@"RoomCell" owner:self options:nil];
        for(id oneObject in nib){
            if([oneObject isKindOfClass:[RoomCell class]]){
                cell = (RoomCell *)oneObject;
                cell.backgroundColor = [UIColor whiteColor];
                cell.RoomNameLb.text = [NSString stringWithFormat:@"房间 %d",[indexPath row]+1];
                
                //长按事件的按钮
//                UIButton *LongPressBtn=[UIButton buttonWithType:UIButtonTypeRoundedRect];
//                [LongPressBtn setFrame:CGRectMake(0, 0, ScrWidth, 50)];
//                [LongPressBtn setBackgroundColor:[UIColor clearColor]];
//                [LongPressBtn addTarget:self action:@selector(ShorPressAction:) forControlEvents:UIControlEventTouchUpInside];
//                //button长按事件
//                UILongPressGestureRecognizer *longPress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(btnLong:)];
//                longPress.minimumPressDuration = 0.5; //定义按的时间
//                [LongPressBtn addGestureRecognizer:longPress];
//
//                [cell addSubview:LongPressBtn];
            }
        }
    }
    return cell;
}

-(void)ShorPressAction:(id)send{
    
    DeviceListVC *List = [[DeviceListVC alloc] init];
    [self.navigationController pushViewController:List animated:YES];
}

-(void)btnLong:(UILongPressGestureRecognizer *)gestureRecognizer
{
    if ([gestureRecognizer state] == UIGestureRecognizerStateBegan) {
        
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"消息" message:@"您确定修改房间信息吗？" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"修改", nil];
        [alert show];
    }
}

//监听点击事件 代理方法
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    NSString *btnTitle = [alertView buttonTitleAtIndex:buttonIndex];
    if ([btnTitle isEqualToString:@"取消"]) {
        NSLog(@"你点击了取消");
    }
    else if ([btnTitle isEqualToString:@"修改"] )
    {
        EditRoomInfoVC *Edit = [[EditRoomInfoVC alloc] init];
        [self.navigationController pushViewController:Edit animated:YES];
    }
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([indexPath section]==0)
    {
        [self ShorPressAction:nil];
        [PassValueMethod shareInstance].pRoomNameStr = [NSString stringWithFormat:@"Room %zd",[indexPath row]+1];
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
