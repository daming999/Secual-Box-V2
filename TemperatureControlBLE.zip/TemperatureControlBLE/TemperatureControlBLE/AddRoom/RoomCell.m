//
//  RoomCell.m
//  TemperatureControlBLE
//
//  Created by 黄文雨 on 2018/8/22.
//  Copyright © 2018年 wenyu. All rights reserved.
//

#import "RoomCell.h"
#import "InvokHeadFile.pch"

@implementation RoomCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    self.RoomNameLb.textColor = TextGaryColor;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
