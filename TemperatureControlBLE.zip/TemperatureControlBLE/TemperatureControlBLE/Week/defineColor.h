//
//  defineColor.h
//  OldManHappy
//
//  Created by 徐清兰 on 2017/3/2.
//  Copyright © 2017年 何. All rights reserved.
//

#ifndef defineColor_h
#define defineColor_h
#define kUIColorFromRGB(rgbValue) [UIColor \
colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 \
green:((float)((rgbValue & 0xFF00) >> 8))/255.0 \
blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0]

#endif /* defineColor_h */
