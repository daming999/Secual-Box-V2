//
//  WLWenduChoose.h
//  TemperatureControlBLE
//
//  Created by 黄文雨 on 2018/9/17.
//  Copyright © 2018年 wenyu. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void (^passWenduToPage)(NSString *Time);
@protocol WLWenduChooseDelegate <NSObject>

- (void)wlTimeChooseDelegateWenduStr:(NSString *)wenduStr;
@end

@interface WLWenduChoose : UIView


+(WLWenduChoose *) shareInstance;
@property(nonatomic,assign)id <WLWenduChooseDelegate> delegate;
@property (nonatomic,strong) passWenduToPage passWenduTopageBlock;
@property (nonatomic, strong) UILabel *titleLable;          //标题时间
@property (nonatomic, strong) UILabel *hourLable;           //显示时
@property (nonatomic, strong) UILabel *minuteLable;         //显示分
@property (nonatomic, strong) UILabel *secondLable;         //显示秒
@property(nonatomic,strong)NSMutableArray *wenduArray;      //时数据源

@property(nonatomic,copy)NSString *wenduStr;                 //时字符

@property (nonatomic, strong) NSCalendar *calendar;         //时间器
@property(nonatomic,strong)UIPickerView *mainPickView;      //选择器
@property(nonatomic,strong) NSString *Wendu;




@end
