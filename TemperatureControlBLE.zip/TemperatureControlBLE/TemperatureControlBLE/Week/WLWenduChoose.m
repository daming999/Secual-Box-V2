//
//  WLWenduChoose.m
//  TemperatureControlBLE
//
//  Created by 黄文雨 on 2018/9/17.
//  Copyright © 2018年 wenyu. All rights reserved.
//

#import "WLWenduChoose.h"
#import "InvokHeadFile.pch"


@interface WLWenduChoose ()<UIPickerViewDataSource,UIPickerViewDelegate>
{
    UIToolbar *toolBar;
    UIBarButtonItem *cancleItem;
    UIBarButtonItem *sureItem;
    NSString *TimeStr;
    UIView *bgView;
}

@end

@implementation WLWenduChoose

static WLWenduChoose *sharedMethod = nil;
+(WLWenduChoose *) shareInstance
{
    if (sharedMethod == nil)
    {
        sharedMethod = [[WLWenduChoose alloc] init];
    }
    return sharedMethod;
}

-(instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        
        self.backgroundColor = [UIColor redColor];
        self.wenduArray = [NSMutableArray array];
 
        self.wenduArray = [[NSMutableArray alloc] initWithObjects:@"00",@"01",@"02",@"03",@"04",@"05",@"06",@"07",@"08",@"09",@"10",@"11",@"12",@"13",@"14",@"15",@"16",@"17",@"18",@"19",@"20",@"21",@"22",@"23",@"24",@"25",@"26",@"27",@"28",@"29",@"30",@"31",@"32",@"33",@"34",@"35",@"36",@"37",@"38",@"39",@"40",@"41",@"42",@"43",@"44",@"45",@"46",@"47",@"48",@"49",@"50",@"51",@"52",@"53",@"54",@"55",@"56",@"57",@"58",@"59",nil];
        
        _calendar = [NSCalendar currentCalendar];
        [UIView animateWithDuration:0.3 animations:^{
            self.alpha = 1;
        }];
        
        [self CreateUI];
    }
    return self;
}

- (void)CreateUI{
    
    self.frame = CGRectMake(0, (HeightScreen - 200), WidthScreen,200);
    bgView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, WidthScreen,200)];
    bgView.backgroundColor = [UIColor lightGrayColor];
    [self addSubview:bgView];
    
    toolBar = [[UIToolbar alloc] init];
    toolBar.barTintColor = BackGroundGaryColor;
    toolBar.frame = CGRectMake(0, 0, WidthScreen, 40);
    cancleItem = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"取消", nil) style:UIBarButtonItemStylePlain target:self action:@selector(buttonClick:)];
    cancleItem.tag = 99;
    UIBarButtonItem *spaceItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace target:self action:nil];
    spaceItem.width = WidthScreen - 100;
    sureItem = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"确认", nil) style:UIBarButtonItemStylePlain target:self action:@selector(buttonClick:)];
    sureItem.tag = 100;
    toolBar.tintColor = [UIColor whiteColor];
    toolBar.items = @[cancleItem, spaceItem, sureItem];
    [bgView addSubview:toolBar];
    
    self.mainPickView = [[UIPickerView alloc] initWithFrame:CGRectMake(0, 40, WidthScreen, 160)];
    self.mainPickView.backgroundColor = [UIColor whiteColor];
    self.mainPickView.dataSource = self;
    self.mainPickView.delegate = self;
    [bgView addSubview:self.mainPickView];
}

- (void)buttonClick:(UIButton *)sender
{
    if (sender.tag == 99) {
        [self nowDate];
        [UIView animateWithDuration:0.3 animations:^{
            self.alpha = 0;
        } completion:^(BOOL finished) {
            [self removeFromSuperview];
        }];
        
        if ([WLTimeChoose shareInstance].passTimeTopageBlock) {
            [WLTimeChoose shareInstance].passTimeTopageBlock([PassValueMethod shareInstance].passCancelTime);
        }
    }
    else if (sender.tag == 100){
        [self nowDate];
        [UIView animateWithDuration:0.3 animations:^{
            self.alpha = 0;
        } completion:^(BOOL finished) {
            [self removeFromSuperview];
        }];
        
        if ([WLTimeChoose shareInstance].passTimeTopageBlock) {
            [WLTimeChoose shareInstance].passTimeTopageBlock(TimeStr);
        }
    }
    else{
        [self.delegate wlTimeChooseDelegateWenduStr:self.wenduStr];
        [UIView animateWithDuration:0.3 animations:^{
            self.alpha = 0;
        } completion:^(BOOL finished) {
            [self removeFromSuperview];
        }];
    }
}

//XXXXXXXXXXXX
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}

//XXXXXXXXXXXX
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    NSLog(@"=====================pickview数组=======================================%@",self.wenduArray);
    return self.wenduArray.count;
}

- (nullable NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    NSLog(@"========================这里是第几个组件========================= %zd",component);
    NSString *wendu = NSLocalizedString(@"°C", nil);

    if (component == 0) {
        NSString *wenduStr = [NSString stringWithFormat:@"%@%@",self.wenduArray[row],wendu];
        NSLog(@"===============pickerview选择的温度============== %@",wenduStr);
        return [NSString stringWithFormat:@"%@%@",self.wenduArray[row],wendu];
    }
    else{

        NSString *minuteStr =  [NSString stringWithFormat:@"%@%@",self.wenduArray[row],wendu];
        return [NSString stringWithFormat:@"%@%@",self.wenduArray[row],wendu];
    }
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    NSString *du = NSLocalizedString(@"°C", nil);
  
    if (component == 0) {
        _wenduStr = [NSString stringWithFormat:@"%@",self.wenduArray[row]];
    }
    
//    self.titleLable.text = [NSString stringWithFormat:@"%@%@ %@%@",_hourStr,hour,_minuteStr,minute];
//    self.hourLable.text = [NSString stringWithFormat:@"%@%@",_hourStr,hour];
//    self.minuteLable.text = [NSString stringWithFormat:@"%@%@",_minuteStr,minute];
//    TimeStr = [NSString stringWithFormat:@"%@:%@",_hourStr,_minuteStr];
}

-(void)setHour:(NSString *)Wendu
{
    _Wendu = Wendu;
    [self.mainPickView reloadAllComponents];
}

- (void)nowDate
{
    if (_wenduStr==nil) {
        _wenduStr = @"00";
    }
    
    TimeStr = [NSString stringWithFormat:@"%@",_wenduStr];
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
