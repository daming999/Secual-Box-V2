//
//  TimeAndWenduSetCell.m
//  TemperatureControlBLE
//
//  Created by 黄文雨 on 2018/9/17.
//  Copyright © 2018年 wenyu. All rights reserved.
//

#import "TimeAndWenduSetCell.h"

@implementation TimeAndWenduSetCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (IBAction)startTimeBtn:(id)sender {
    
    if ([PassBlock shareInstance].ShowStartTimeBlcok) {
        [PassBlock shareInstance].ShowStartTimeBlcok();
    }
}

- (IBAction)endTimeBtn:(id)sender {
    
    if ([PassBlock shareInstance].ShowEndTimeBlock) {
        [PassBlock shareInstance].ShowEndTimeBlock();
    }
}

- (IBAction)wenduBtn:(id)sender {
    
    if([PassBlock shareInstance].ShowWenduBlock){
        [PassBlock shareInstance].ShowWenduBlock();
    }
}


@end
