//
//  WeekProgrammeVC.m
//  TemperatureControlBLE
//
//  Created by 黄文雨 on 2018/8/23.
//  Copyright © 2018年 wenyu. All rights reserved.
//

#import "WeekProgrammeVC.h"
#import "InvokHeadFile.pch"

@interface WeekProgrammeVC ()

@end

@implementation WeekProgrammeVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.TitleLb.text = NSLocalizedString(@"星期编程", nil);
    [self LoadSubView];
}

-(void)LoadSubView
{
    CGFloat weekTitleLbjjH = ScrHeight *0.146;
    UILabel *weekTitleLb = [[UILabel alloc] initWithFrame:CGRectMake(0, weekTitleLbjjH, ScrWidth, 35)];
    weekTitleLb.textColor = TextGaryColor;
    weekTitleLb.text = NSLocalizedString(@"Week Programming", nil);
    weekTitleLb.font = [UIFont systemFontOfSize:15.0];
    weekTitleLb.textAlignment = UITextAlignmentCenter;
    [self.view addSubview:weekTitleLb];
    
    CGFloat BtnW = 30;
    CGFloat BtnjjW = (ScrWidth-(BtnW*7))/8;
    CGFloat BtnjjH = ScrHeight *0.225;
    CGFloat BtnH = 40;
    
    UIButton *sundayBtn = [[UIButton alloc] initWithFrame:CGRectMake(BtnjjW, BtnjjH, BtnW, BtnH)];
    sundayBtn.tag = 200;
    [sundayBtn setImage:[UIImage imageNamed:@"s_low"] forState:UIControlStateNormal];
    [sundayBtn addTarget:self action:@selector(SetModelBtnAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:sundayBtn];
    
    UIButton *mondayBtn = [[UIButton alloc] initWithFrame:CGRectMake(BtnjjW*2+BtnW, BtnjjH, BtnW, BtnH)];
    mondayBtn.tag = 200;
    [mondayBtn setImage:[UIImage imageNamed:@"m_low"] forState:UIControlStateNormal];
    [mondayBtn addTarget:self action:@selector(SetModelBtnAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:mondayBtn];
    
    UIButton *tuesdayBtn = [[UIButton alloc] initWithFrame:CGRectMake(BtnjjW*3+BtnW*2, BtnjjH, BtnW, BtnH)];
    tuesdayBtn.tag = 200;
    [tuesdayBtn setImage:[UIImage imageNamed:@"t_deep"] forState:UIControlStateNormal];
    [tuesdayBtn addTarget:self action:@selector(SetModelBtnAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:tuesdayBtn];
    
    UIButton *wednesdayBtn = [[UIButton alloc] initWithFrame:CGRectMake(BtnjjW*4+BtnW*3, BtnjjH, BtnW,BtnH)];
    wednesdayBtn.tag = 200;
    [wednesdayBtn setImage:[UIImage imageNamed:@"w_low"] forState:UIControlStateNormal];
    [wednesdayBtn addTarget:self action:@selector(SetModelBtnAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:wednesdayBtn];
    
    UIButton *thursdayBtn = [[UIButton alloc] initWithFrame:CGRectMake(BtnjjW*5+BtnW*4, BtnjjH, BtnW, BtnH)];
    thursdayBtn.tag = 200;
    [thursdayBtn setImage:[UIImage imageNamed:@"t_low"] forState:UIControlStateNormal];
    [thursdayBtn addTarget:self action:@selector(SetModelBtnAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:thursdayBtn];
    
    UIButton *fridayBtn = [[UIButton alloc] initWithFrame:CGRectMake(BtnjjW*6+BtnW*5, BtnjjH, BtnW, BtnH)];
    fridayBtn.tag = 200;
    [fridayBtn setImage:[UIImage imageNamed:@"f_low"] forState:UIControlStateNormal];
    [fridayBtn addTarget:self action:@selector(SetModelBtnAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:fridayBtn];
    
    UIButton *saturdayBtn = [[UIButton alloc] initWithFrame:CGRectMake(BtnjjW*7+BtnW*6, BtnjjH, BtnW, BtnH)];
    saturdayBtn.tag = 200;
    [saturdayBtn setImage:[UIImage imageNamed:@"s_low"] forState:UIControlStateNormal];
    [saturdayBtn addTarget:self action:@selector(SetModelBtnAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:saturdayBtn];
    
    CGFloat BingWH = ScrHeight *0.41;
    CGFloat BingjjH = ScrHeight *0.363;
    UIImageView *BingImageV = [[UIImageView alloc] initWithFrame:CGRectMake((ScrWidth-BingWH)/2, BingjjH, BingWH, BingWH)];
    BingImageV.image = [UIImage imageNamed:@"bing_scalepng"];
    [self.view addSubview:BingImageV];
    
    //白天低温
    UIButton *DayTimeLowWenduBtn = [[UIButton alloc] initWithFrame:CGRectMake((ScrWidth-BingWH)/2, BingImageV.frame.origin.y, BingWH/2, BingWH/2)];
    [DayTimeLowWenduBtn setTitle:@"21°C" forState:UIControlStateNormal];
    DayTimeLowWenduBtn.tag =  100;
    [DayTimeLowWenduBtn setTitleColor:TextGaryColor forState:UIControlStateNormal];
    [DayTimeLowWenduBtn addTarget:self action:@selector(WenduBtn:) forControlEvents:UIControlEventTouchUpInside];
    DayTimeLowWenduBtn.backgroundColor = BackGroudClearColor;
    [self.view addSubview:DayTimeLowWenduBtn];
    
    //白天高温
    UIButton *DayTimeHighWenduBtn = [[UIButton alloc] initWithFrame:CGRectMake((ScrWidth-BingWH)/2, BingImageV.frame.origin.y+BingWH/2, BingWH/2, BingWH/2)];
    [DayTimeHighWenduBtn setTitle:@"30°C" forState:UIControlStateNormal];
    DayTimeHighWenduBtn.tag = 200;
    [DayTimeHighWenduBtn setTitleColor:TextGaryColor forState:UIControlStateNormal];
    [DayTimeHighWenduBtn addTarget:self action:@selector(WenduBtn:) forControlEvents:UIControlEventTouchUpInside];
    DayTimeHighWenduBtn.backgroundColor = BackGroudClearColor;
    [self.view addSubview:DayTimeHighWenduBtn];
    
    //晚上低温
    UIButton *NightLowWenduBtn = [[UIButton alloc] initWithFrame:CGRectMake((ScrWidth-BingWH)/2+BingWH/2, BingImageV.frame.origin.y, BingWH/2, BingWH/2)];
    [NightLowWenduBtn setTitle:@"23°C" forState:UIControlStateNormal];
    NightLowWenduBtn.tag = 300;
    [NightLowWenduBtn setTitleColor:TextGaryColor forState:UIControlStateNormal];
    [NightLowWenduBtn addTarget:self action:@selector(WenduBtn:) forControlEvents:UIControlEventTouchUpInside];
    NightLowWenduBtn.backgroundColor = BackGroudClearColor;
    [self.view addSubview:NightLowWenduBtn];
    
    //晚上高温
    UIButton *NightHighWenduBtn = [[UIButton alloc] initWithFrame:CGRectMake((ScrWidth-BingWH)/2+BingWH/2, BingImageV.frame.origin.y+BingWH/2, BingWH/2, BingWH/2)];
    [NightHighWenduBtn setTitle:@"35°C" forState:UIControlStateNormal];
    NightHighWenduBtn.tag = 400;
    [NightHighWenduBtn setTitleColor:TextGaryColor forState:UIControlStateNormal];
    [NightHighWenduBtn addTarget:self action:@selector(WenduBtn:) forControlEvents:UIControlEventTouchUpInside];
    NightHighWenduBtn.backgroundColor = BackGroudClearColor;
    [self.view addSubview:NightHighWenduBtn];
}

-(void)WenduBtn:(UIButton *)send{
    
    if (send.tag==100) {
        
    }
    else if (send.tag==200){
        
    }
    else if (send.tag==300){
        
    }
    else if (send.tag==400){
        
    }
    
    TimeAndWenduSetVC *WenduSet = [[TimeAndWenduSetVC alloc] init];
    [self.navigationController pushViewController:WenduSet animated:YES];
}

-(void)SetModelBtnAction:(id)send{
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
