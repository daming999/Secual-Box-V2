//
//  TimeAndWenduSetCell.h
//  TemperatureControlBLE
//
//  Created by 黄文雨 on 2018/9/17.
//  Copyright © 2018年 wenyu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "InvokHeadFile.pch"
#import "WLTimeChoose.h"

@interface TimeAndWenduSetCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *FromLb;
@property (strong, nonatomic) IBOutlet UIButton *StartTimeBtn;
@property (strong, nonatomic) IBOutlet UILabel *ToLb;
@property (strong, nonatomic) IBOutlet UIButton *EndTimeBtn;
@property (strong, nonatomic) IBOutlet UIButton *WenduBtn;
@property (strong, nonatomic)  WLTimeChoose *timeChoose;
@end
