//
//  WLTimeChoose.m
//  时间选择器
//
//  Created by zerocc on 16/11/2.
//  Copyright © 2016年 he. All rights reserved.
//

#import "WLTimeChoose.h"
#import "InvokHeadFile.pch"

@interface WLTimeChoose ()<UIPickerViewDataSource,UIPickerViewDelegate>
{
     UIToolbar *toolBar;
     UIBarButtonItem *cancleItem;
     UIBarButtonItem *sureItem;
     NSString *TimeStr;
     UIView *bgView;
}

@end

@implementation WLTimeChoose

static WLTimeChoose *sharedMethod = nil;
+(WLTimeChoose *) shareInstance
{
    if (sharedMethod == nil)
    {
        sharedMethod = [[WLTimeChoose alloc] init];
    }
    return sharedMethod;
}

-(instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        
        self.backgroundColor = [UIColor redColor];
        self.hourArray = [NSMutableArray array];
        self.minuteArray = [NSMutableArray array];
        self.secondArray = [NSMutableArray array];
        
        self.hourArray = [[NSMutableArray alloc] initWithObjects:@"00",@"01",@"02",@"03",@"04",@"05",@"06",@"07",@"08",@"09",@"10",@"11",@"12",@"13",@"14",@"15",@"16",@"17",@"18",@"19",@"20",@"21",@"22",@"23",nil];
        self.minuteArray = [[NSMutableArray alloc] initWithObjects:@"00",@"01",@"02",@"03",@"04",@"05",@"06",@"07",@"08",@"09",@"10",@"11",@"12",@"13",@"14",@"15",@"16",@"17",@"18",@"19",@"20",@"21",@"22",@"23",@"24",@"25",@"26",@"27",@"28",@"29",@"30",@"31",@"32",@"33",@"34",@"35",@"36",@"37",@"38",@"39",@"40",@"41",@"42",@"43",@"44",@"45",@"46",@"47",@"48",@"49",@"50",@"51",@"52",@"53",@"54",@"55",@"56",@"57",@"58",@"59",nil];
        
        _calendar = [NSCalendar currentCalendar];
        [UIView animateWithDuration:0.3 animations:^{
            self.alpha = 1;
        }];
        
        [self CreateUI];
    }
    return self;
}

- (void)CreateUI{
    
    self.frame = CGRectMake(0, (HeightScreen - 200), WidthScreen,200);
    bgView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, WidthScreen,200)];
    bgView.backgroundColor = [UIColor lightGrayColor];
    [self addSubview:bgView];
    
    toolBar = [[UIToolbar alloc] init];
    toolBar.barTintColor = BackGroundGaryColor;
    toolBar.frame = CGRectMake(0, 0, WidthScreen, 40);
    cancleItem = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"取消", nil) style:UIBarButtonItemStylePlain target:self action:@selector(buttonClick:)];
    cancleItem.tag = 99;
    UIBarButtonItem *spaceItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace target:self action:nil];
    spaceItem.width = WidthScreen - 100;
    sureItem = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"确认", nil) style:UIBarButtonItemStylePlain target:self action:@selector(buttonClick:)];
    sureItem.tag = 100;
    toolBar.tintColor = [UIColor whiteColor];
    toolBar.items = @[cancleItem, spaceItem, sureItem];
    [bgView addSubview:toolBar];
    
    self.mainPickView = [[UIPickerView alloc] initWithFrame:CGRectMake(0, 40, WidthScreen, 160)];
    self.mainPickView.backgroundColor = [UIColor whiteColor];
    self.mainPickView.dataSource = self;
    self.mainPickView.delegate = self;
    [bgView addSubview:self.mainPickView];
}

- (void)buttonClick:(UIButton *)sender
{
    if (sender.tag == 99) {
        
        [self nowDate];
        
        [UIView animateWithDuration:0.3 animations:^{
            self.alpha = 0;
        } completion:^(BOOL finished) {
            [self removeFromSuperview];
        }];
        
        if ([WLTimeChoose shareInstance].passTimeTopageBlock) {
            [WLTimeChoose shareInstance].passTimeTopageBlock([PassValueMethod shareInstance].passCancelTime);
        }
    }
    else if (sender.tag == 100){
        [self nowDate];
        [UIView animateWithDuration:0.3 animations:^{
            self.alpha = 0;
        } completion:^(BOOL finished) {
            [self removeFromSuperview];
        }];
        
        if ([WLTimeChoose shareInstance].passTimeTopageBlock) {
            [WLTimeChoose shareInstance].passTimeTopageBlock(TimeStr);
        }
    }
    else{
        [self.delegate wlTimeChooseDelegateHourStr:self.hourStr minuteStr:self.minuteStr secondStr:self.secondStr];
        [UIView animateWithDuration:0.3 animations:^{
            self.alpha = 0;
        } completion:^(BOOL finished) {
            [self removeFromSuperview];
        }];
    }
}

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 2;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    if (component == 0) {
        return self.hourArray.count;
    }
    else{
        return self.minuteArray.count;
    }
}

- (nullable NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    NSString *hour = NSLocalizedString(@"时", nil);
    NSString *minute = NSLocalizedString(@"分", nil);
    if (component == 0) {
         NSString *timeStr = [NSString stringWithFormat:@"%@%@",self.hourArray[row],hour];
        return [NSString stringWithFormat:@"%@%@",self.hourArray[row],hour];
    }else{
        NSString *minuteStr =  [NSString stringWithFormat:@"%@%@",self.minuteArray[row],minute];
        return [NSString stringWithFormat:@"%@%@",self.minuteArray[row],minute];
     }
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    NSString *hour = NSLocalizedString(@"时", nil);
    NSString *minute = NSLocalizedString(@"分", nil);
    if (component == 0) {
        _hourStr = [NSString stringWithFormat:@"%@",self.hourArray[row]];
    }
    else if (component == 1){
        _minuteStr = [NSString stringWithFormat:@"%@",self.minuteArray[row]];
    }
    self.titleLable.text = [NSString stringWithFormat:@"%@%@ %@%@",_hourStr,hour,_minuteStr,minute];
    self.hourLable.text = [NSString stringWithFormat:@"%@%@",_hourStr,hour];
    self.minuteLable.text = [NSString stringWithFormat:@"%@%@",_minuteStr,minute];
    TimeStr = [NSString stringWithFormat:@"%@:%@",_hourStr,_minuteStr];
}

-(void)setHour:(NSString *)Hour
{
    _Hour = Hour;
    _hourStr = _Hour;
    [self.mainPickView reloadAllComponents];
}

-(void)setMin:(NSString *)Min
{
    _Min = Min;
    _minuteStr = _Min;
    [self.mainPickView reloadAllComponents];
}

- (void)nowDate
{
    if (_hourStr==nil) {
        _hourStr = @"00";
    }
    if (_minuteStr==nil) {
        _minuteStr = @"00";
    }
    TimeStr = [NSString stringWithFormat:@"%@:%@",_hourStr,_minuteStr];
}

@end
