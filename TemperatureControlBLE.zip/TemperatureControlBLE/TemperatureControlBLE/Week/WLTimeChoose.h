//
//  WLTimeChoose.h
//  时间选择器
//
//  Created by zerocc on 16/11/2.
//  Copyright © 2016年 qinguo.company. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void (^passTimeToPage)(NSString *Time);
@protocol WLTimeChooseDelegate <NSObject>

- (void)wlTimeChooseDelegateHourStr:(NSString *)hourStr minuteStr:(NSString *)minuteStr secondStr:(NSString *)secondStr;

@end

@interface WLTimeChoose : UIView
+(WLTimeChoose *) shareInstance;
@property(nonatomic,assign)id <WLTimeChooseDelegate> delegate;
@property (nonatomic,strong) passTimeToPage passTimeTopageBlock;
@property (nonatomic, strong) UILabel *titleLable;          //标题时间
@property (nonatomic, strong) UILabel *hourLable;           //显示时
@property (nonatomic, strong) UILabel *minuteLable;         //显示分
@property (nonatomic, strong) UILabel *secondLable;         //显示秒
@property(nonatomic,strong)NSMutableArray *hourArray;       //时数据源
@property(nonatomic,strong)NSMutableArray *minuteArray;     //分数据源
@property(nonatomic,strong)NSMutableArray *secondArray;     //秒数据源
@property(nonatomic,copy)NSString *hourStr;                 //时字符
@property(nonatomic,copy)NSString *minuteStr;               //分字符
@property(nonatomic,copy)NSString *secondStr;               //秒字符
@property (nonatomic, strong) NSCalendar *calendar;         //时间器
@property(nonatomic,strong)UIPickerView *mainPickView;      //选择器
@property(nonatomic,strong) NSString *Hour;
@property(nonatomic,strong) NSString *Min;
@end


