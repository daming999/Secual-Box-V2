//
//  TimeAndWenduSetVC.m
//  TemperatureControlBLE
//
//  Created by 黄文雨 on 2018/9/17.
//  Copyright © 2018年 wenyu. All rights reserved.
//

#import "TimeAndWenduSetVC.h"
#import "InvokHeadFile.pch"
#define CellCount 5
@interface TimeAndWenduSetVC ()
@property (nonatomic,strong) UITableView *TableViewList;
@property (nonatomic,strong) WLTimeChoose *timeChoose;
@property (nonatomic,strong) WLWenduChoose *wenduChoose;
@property (nonatomic,strong) NSString * HourStr;
@property (nonatomic,strong) NSString *MinuteStr;
@property (nonatomic,strong) NSString *SetStartTimeStr;
@property (nonatomic,strong) NSString *SetEndTimeStr;
@end

@implementation TimeAndWenduSetVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.TitleLb.text = NSLocalizedString(@"房间名称", nil);

    [self.NavRightBtn setImage:[UIImage imageNamed:@"nav_checkmark_normal"] forState:UIControlStateNormal];
    [self LoadSubView];
    
    [PassBlock shareInstance].ShowStartTimeBlcok = ^{
        
        _timeChoose = [[WLTimeChoose alloc] initWithFrame:CGRectMake(0, 0, WidthScreen, HeightScreen)];
        [self.view addSubview:_timeChoose];
    
        NSString *startTimeBtnStr = @"09:00";
        NSString *HourStr = [startTimeBtnStr substringWithRange:NSMakeRange(0, 2)];//截取时间
        NSString *MinuteStr = [startTimeBtnStr substringWithRange:NSMakeRange(3, 2)];//截取时间
        _timeChoose.Hour = HourStr;
        _timeChoose.Min = MinuteStr;

        NSString *passTimeStr = [NSString stringWithFormat:@"%@:%@",HourStr,MinuteStr];
        [PassValueMethod shareInstance].passCancelTime = passTimeStr;

        [_timeChoose.mainPickView selectRow:[HourStr integerValue] inComponent:0 animated:YES];
        [_timeChoose.mainPickView selectRow:[MinuteStr integerValue] inComponent:1 animated:YES];

        [WLTimeChoose shareInstance].passTimeTopageBlock = ^(NSString *a){
            _HourStr = [a substringWithRange:NSMakeRange(0, 2)];
            _MinuteStr = [a substringWithRange:NSMakeRange(3, 2)];
            NSString *startHourStr = [a substringWithRange:NSMakeRange(0, 2)];
            NSString *startMinuteStr = [a substringWithRange:NSMakeRange(3, 2)];
            _SetStartTimeStr = [NSString stringWithFormat:@"%@%@",startHourStr,startMinuteStr];
            NSLog(@"=====================选择开始时间======================= %@",_SetStartTimeStr);
            //[_startTimeBt setTitle:a forState:UIControlStateNormal];
            [_TableViewList reloadData];
        };
    };
    
    [PassBlock shareInstance].ShowEndTimeBlock = ^{
        
        _timeChoose = [[WLTimeChoose alloc] initWithFrame:CGRectMake(0, 0, WidthScreen, HeightScreen)];
        [self.view addSubview:_timeChoose];
        
       // NSString *endTimeBtnStr = [_endTimeBt titleForState:UIControlStateNormal];
        NSString *endTimeBtnStr = @"00:00";
        NSString *HourStr = [endTimeBtnStr substringWithRange:NSMakeRange(0, 2)];
        NSString *MinuteStr = [endTimeBtnStr substringWithRange:NSMakeRange(3, 2)];
        
        NSString *passTimeStr = [NSString stringWithFormat:@"%@:%@",HourStr,MinuteStr];
        [PassValueMethod shareInstance].passCancelTime = passTimeStr;
        
        _timeChoose.Hour = HourStr;
        _timeChoose.Min = MinuteStr;
        [_timeChoose.mainPickView selectRow:[HourStr integerValue] inComponent:0 animated:YES];
        [_timeChoose.mainPickView selectRow:[MinuteStr integerValue] inComponent:1 animated:YES];
        
        [WLTimeChoose shareInstance].passTimeTopageBlock = ^(NSString *a){
            _HourStr = [a substringWithRange:NSMakeRange(0, 2)];
            _MinuteStr = [a substringWithRange:NSMakeRange(3, 2)];
            NSString *endHourStr = [a substringWithRange:NSMakeRange(0, 2)];
            NSString *endMinuteStr = [a substringWithRange:NSMakeRange(3, 2)];
            _SetEndTimeStr = [NSString stringWithFormat:@"%@%@",endHourStr,endMinuteStr];
            NSLog(@"=====================选择结束时间======================= %@",_SetEndTimeStr);
           // [_endTimeBt setTitle:a forState:UIControlStateNormal];
            [_TableViewList reloadData];
        };
    };
   
    
    [PassBlock shareInstance].ShowWenduBlock = ^{
        _wenduChoose = [[WLWenduChoose alloc] initWithFrame:CGRectMake(0, 0, WidthScreen, HeightScreen)];
        [self.view addSubview:_wenduChoose];
    };
}

-(void)LoadSubView
{
    _TableViewList = [[UITableView alloc] initWithFrame:CGRectMake(0, 166, ScrWidth, ScrHeight) style:UITableViewStyleGrouped];
    _TableViewList.separatorStyle = UITableViewStyleGrouped;
    [_TableViewList setBackgroundColor:[UIColor whiteColor]];
    _TableViewList.separatorColor = [UIColor grayColor];
    _TableViewList.showsVerticalScrollIndicator = YES;
    _TableViewList.scrollEnabled = NO;
    _TableViewList.delegate = self;
    _TableViewList.dataSource = self;
    _TableViewList.estimatedRowHeight = 0;
    if (@available(iOS 11.0, *)) {
        _TableViewList.estimatedSectionHeaderHeight = 0;
        _TableViewList.estimatedSectionFooterHeight = 0;
    }
    [self.view addSubview:_TableViewList];
    
    
    if ([_TableViewList respondsToSelector:@selector(setSeparatorInset:)]) {
        [_TableViewList setSeparatorInset:UIEdgeInsetsZero];
    }
    if ([_TableViewList respondsToSelector:@selector(setLayoutMargins:)]) {
        [_TableViewList setLayoutMargins:UIEdgeInsetsZero];
    }
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([cell respondsToSelector:@selector(setSeparatorInset:)])
    {
        [cell setSeparatorInset:UIEdgeInsetsZero];
    }
    
    if ([cell respondsToSelector:@selector(setLayoutMargins:)])
    {
        [cell setLayoutMargins:UIEdgeInsetsZero];
    }
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView;
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return CellCount;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 50;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (section == 0) {
        return 0.0001;
    }else{
        return 10;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *tableCellIdentifier = @"TimeAndWenduSetCell";
    TimeAndWenduSetCell *cell = (TimeAndWenduSetCell *)[tableView dequeueReusableCellWithIdentifier:tableCellIdentifier];
    if(cell == nil){
        NSArray *nib = [[NSBundle mainBundle]loadNibNamed:@"TimeAndWenduSetCell" owner:self options:nil];
        for(id oneObject in nib){
            if([oneObject isKindOfClass:[TimeAndWenduSetCell class]]){
                
                cell = (TimeAndWenduSetCell *)oneObject;
                [cell.StartTimeBtn setTitle:@"02:20" forState:UIControlStateNormal];
                cell.backgroundColor = [UIColor whiteColor];
                
                if (indexPath.row==CellCount-1) {
                    cell.FromLb.hidden = YES;
                    cell.StartTimeBtn.hidden = YES;
                    cell.ToLb.hidden = YES;
                    cell.EndTimeBtn.hidden = YES;
                    cell.WenduBtn.hidden = YES;
                }
            }
        }
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([indexPath section]==0)
    {
       
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
