//
//  define.h
//  LaoLe
//
//  Created by 徐清兰 on 16/10/21.
//  Copyright © 2016年 何. All rights reserved.
//

#import <Foundation/Foundation.h>
#define WidthScreen [UIScreen mainScreen].bounds.size.width
#define HeightScreen [UIScreen mainScreen].bounds.size.height
@interface define : NSObject

@end
