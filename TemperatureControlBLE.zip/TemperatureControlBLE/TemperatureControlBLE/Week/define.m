//
//  define.m
//  LaoLe
//
//  Created by 徐清兰 on 16/10/21.
//  Copyright © 2016年 何. All rights reserved.
//

#import "define.h"

@implementation define

@end
