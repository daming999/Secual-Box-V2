//
//  LoginViewController.m
//  TemperatureControlBLE
//
//  Created by 黄文雨 on 2018/8/21.
//  Copyright © 2018年 wenyu. All rights reserved.
//

#import "LoginViewController.h"
#import "InvokHeadFile.pch"

@interface LoginViewController ()

@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self LoadSubView];
}

-(void)LoadSubView{
    
    UIButton *LogoBtn = [[UIButton alloc] initWithFrame:CGRectMake((ScrWidth-80)/2, ScrHeight-100, 80, 30)];
    LogoBtn.backgroundColor = [UIColor blueColor];
    [LogoBtn addTarget:self action:@selector(LoginBtn:) forControlEvents:UIControlEventTouchUpInside];
    [LogoBtn setTitle:NSLocalizedString(@"Login", nil) forState:UIControlStateNormal];
    [self.view addSubview:LogoBtn];
    self.NavBackV.hidden = YES;
}

-(void)LoginBtn:(id)send{
    AddDeviceViewController *device = [[AddDeviceViewController alloc] init];
    [self.navigationController pushViewController:device animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
