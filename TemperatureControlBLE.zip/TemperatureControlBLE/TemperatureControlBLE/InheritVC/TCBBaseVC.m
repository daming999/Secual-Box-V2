//
//  TCBBaseVC.m
//  TemperatureControlBLE
//
//  Created by 黄文雨 on 2018/8/20.
//  Copyright © 2018年 wenyu. All rights reserved.
//

#import "TCBBaseVC.h"
#import "InvokHeadFile.pch"
@interface TCBBaseVC ()

@end

@implementation TCBBaseVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    IQKeyboardManager *manager = [IQKeyboardManager sharedManager];
    manager.enable = YES;
    manager.shouldResignOnTouchOutside =YES;
    manager.shouldToolbarUsesTextFieldTintColor =YES;
    manager.enableAutoToolbar =YES;
    manager.toolbarManageBehaviour = IQAutoToolbarByTag;
    [IQKeyboardManager sharedManager].shouldToolbarUsesTextFieldTintColor = NO;
    [IQKeyboardManager sharedManager].toolbarTintColor = [UIColor grayColor];
    
    _NavBackV = [[UIView alloc] initWithFrame:CGRectMake(0, 0, ScrWidth, 64)];
    _NavBackV.backgroundColor = BackGroundGaryColor;
    [self.view addSubview:_NavBackV];
    
    _DeviceSmallImg = [[UIImageView alloc] initWithFrame:CGRectMake(25, 21, 60, 40)];
    [_DeviceSmallImg setImage:[UIImage imageNamed:@"device_Small"]];
    [_NavBackV addSubview: _DeviceSmallImg];
    
    _BackBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 15, 50, 50)];
    [_BackBtn setImage:[UIImage imageNamed:@"black_back.png"] forState:UIControlStateNormal];
    [_BackBtn addTarget:self action:@selector(Back:) forControlEvents:UIControlEventTouchUpInside];
    [_NavBackV addSubview:_BackBtn];
    
    _NavRightBtn = [[UIButton alloc] initWithFrame:CGRectMake(ScrWidth-45, 25, 35, 35)];
    [_NavRightBtn setImage:[UIImage imageNamed:@"sandian"] forState:UIControlStateNormal];
    [_NavBackV addSubview:_NavRightBtn];
    
    _TitleLb = [[UILabel alloc] initWithFrame:CGRectMake(_DeviceSmallImg.frame.origin.x+50, 15, 150, 50)];
    _TitleLb.font = [UIFont systemFontOfSize:16.0];
    _TitleLb.textAlignment = UITextAlignmentLeft;
    _TitleLb.text = NSLocalizedString(@"Teach-in device", nil);
    _TitleLb.textColor = [UIColor whiteColor];
    [_NavBackV addSubview:_TitleLb];
    
    [self.view setBackgroundColor:[UIColor whiteColor]];
}

-(void)Back:(id)send{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
