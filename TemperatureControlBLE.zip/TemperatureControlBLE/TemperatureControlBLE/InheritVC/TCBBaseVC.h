//
//  TCBBaseVC.h
//  TemperatureControlBLE
//
//  Created by 黄文雨 on 2018/8/20.
//  Copyright © 2018年 wenyu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TCBBaseVC : UIViewController
@property (nonatomic,strong) UIView *NavBackV;
@property (nonatomic,strong) UIButton *BackBtn;
@property (nonatomic,strong) UILabel *TitleLb;
@property (nonatomic,strong) UIButton *NavRightBtn;
@property (nonatomic,strong) UIImageView *DeviceSmallImg;
@end
