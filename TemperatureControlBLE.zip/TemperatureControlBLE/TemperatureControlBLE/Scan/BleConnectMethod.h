//
//  BleConnectMethod.h
//  蓝牙模式
//
//  Created by 徐清兰 on 2017/10/23.
//  Copyright © 2017年 何. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import "BleSharedMethod.h"

@interface BleConnectMethod : NSObject<CBCentralManagerDelegate,CBPeripheralDelegate>
{
    CBCharacteristic *writeCharacteristic;
    NSString *AppendIMEIStr;
    NSString *ConnectStr;
}

@property (nonatomic, strong) CBCentralManager *centralManager;
@property (nonatomic, strong) NSMutableArray *peripherals;
@property (nonatomic, strong) CBPeripheral *cbPeripheral;
@property (nonatomic, assign) CBManagerState peripheralState;

+(BleConnectMethod *)sharedInstance;
-(void)scanBle;
-(void)connectToPeripheral;
-(void)disconnectToPeriohereal;
@end

static NSString * const kBlePeripheralName = @"LAOLE-YN01";
static NSString * const kNotifyServerUUID = @"FFF0";
static NSString * const kWriteServerUUID = @"0000FFF0-0000-1000-8000-00805F9B34FB";
static NSString * const kNotifyCharacteristicUUID = @"0000FFF4-0000-1000-8000-00805F9B34FB";
static NSString * const kWriteCharacteristicUUID = @"0000FFF3-0000-1000-8000-00805F9B34FB";


