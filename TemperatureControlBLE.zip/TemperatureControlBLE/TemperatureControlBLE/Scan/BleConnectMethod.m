
//
//  BleConnectMethod.m
//  蓝牙模式
//
//  Created by 徐清兰 on 2017/10/23.
//  Copyright © 2017年 何. All rights reserved.
//

#import "BleConnectMethod.h"
#import "stringTransitionDictionary.h"
#import "BleClientBlock.h"
#import "AFNetworking.h"



@implementation BleConnectMethod

static BleConnectMethod *share = nil;
+(BleConnectMethod *)sharedInstance
{
    static dispatch_once_t pred;
    dispatch_once(&pred, ^{
        share = [[self alloc] init];
    });
    return share;
}

- (NSMutableArray *)peripherals
{
    if (!_peripherals) {
        _peripherals = [NSMutableArray array];
    }
    return _peripherals;
}

//11111
-(CBCentralManager *)centralManager
{
    NSLog(@"=================第 1 步==================");
    if ((![BleSharedMethod sharedInstance].centralManager)) {
        [BleSharedMethod sharedInstance].centralManager = [[CBCentralManager alloc] initWithDelegate:self queue:nil];
    }
    return [BleSharedMethod sharedInstance].centralManager;
}

//2222
-(void)scanBle
{
    NSLog(@"=================第 2 步==================");
    if ([BleSharedMethod sharedInstance].peripheralState ==  CBManagerStatePoweredOn){
        
        [[BleSharedMethod sharedInstance].centralManager scanForPeripheralsWithServices:nil options:nil];
    }
    else{

    }
}

-(void)connectToPeripheral
{
    if ([BleSharedMethod sharedInstance].cbPeripheral != nil){
    
        [[BleSharedMethod sharedInstance].centralManager connectPeripheral:[BleSharedMethod sharedInstance].cbPeripheral options:0];
    }
    else{
   
    }
}

-(void)disconnectToPeriohereal
{
    [self.peripherals removeAllObjects];
    
    if ([BleSharedMethod sharedInstance].cbPeripheral != nil)
    {
        //[BleSharedMethod sharedInstance].IsOpenBlueTooth = NO;
        NSLog(@"---------手动断开连接--------------");
        [BleSharedMethod sharedInstance].BleIsConnectName = nil;
        [[BleSharedMethod sharedInstance].centralManager cancelPeripheralConnection:[BleSharedMethod sharedInstance].cbPeripheral];//链接11111111
        
        NSString *appendStr = [NSString stringWithFormat:@"DISCONNECTBLE"];
        NSData* xmlData = [appendStr dataUsingEncoding:NSUTF8StringEncoding];
        
        if ([[BleSharedMethod sharedInstance].writeCharacteristicUUIdStr isEqualToString:@"0000FFF3-0000-1000-8000-00805F9B34FB"]) {
            [[BleSharedMethod sharedInstance].cbPeripheral writeValue:xmlData forCharacteristic:[BleSharedMethod sharedInstance].writeCharacteristic type:CBCharacteristicWriteWithResponse];
            [BleSharedMethod sharedInstance].writeCharacteristicUUIdStr = nil;
        }
        else{
            NSLog(@"-----------------没有连接设备，不可以发送数据-------------------------");
        }
    }
}


- (void)centralManagerDidUpdateState:(CBCentralManager *)central
{
    switch (central.state) {
        case CBManagerStateUnknown:{
            [BleSharedMethod sharedInstance].peripheralState = central.state;
        }
            break;
        case CBManagerStateResetting:
        {
            NSLog(@"重置状态");
            [BleSharedMethod sharedInstance].peripheralState = central.state;
        }
            break;
        case CBManagerStateUnsupported:
        {
            NSLog(@"不支持的状态");
            [BleSharedMethod sharedInstance].peripheralState = central.state;
        }
            break;
        case CBManagerStateUnauthorized:
        {
            NSLog(@"未授权的状态");
            [BleSharedMethod sharedInstance].peripheralState = central.state;
        }
            break;
        case CBManagerStatePoweredOff:
        {
            NSLog(@"关闭状态 = %zd",central.state);
            [BleSharedMethod sharedInstance].IsOpenBlueTooth = NO;
            [[NSNotificationCenter defaultCenter] postNotificationName:@"DISCONNECTBLE" object:nil];
            [BleSharedMethod sharedInstance].peripheralState = central.state;
            
            NSUserDefaults *BleConnectCache = [NSUserDefaults standardUserDefaults];
            [BleConnectCache removeObjectForKey:@"Ble"];
            [BleConnectCache synchronize];
        }
            break;
        case CBManagerStatePoweredOn:
        {
            [BleSharedMethod sharedInstance].IsOpenBlueTooth = YES;
            NSLog(@"开启状态－可用状态 = %zd",central.state);
            [BleSharedMethod sharedInstance].peripheralState = central.state;
            NSLog(@"%ld",(long)self.peripheralState);
        }
            break;
        default:
            break;
    }
}

//
- (void)centralManager:(CBCentralManager *)central didDiscoverPeripheral:(CBPeripheral *)peripheral advertisementData:(NSDictionary<NSString *,id> *)advertisementData RSSI:(NSNumber *)RSSI
{
    NSLog(@"==============第 3 步=================");
    [BleSharedMethod sharedInstance].cbPeripheral = peripheral;
    [BleSharedMethod sharedInstance].cbPeripheral.delegate = self;//代理
    [[BleSharedMethod sharedInstance].centralManager connectPeripheral:[BleSharedMethod sharedInstance].cbPeripheral options:0];//连接外围
}

- (void)centralManager:(CBCentralManager *)central willRestoreState:(NSDictionary<NSString *, id> *)dict
{
    NSLog(@"-----------------将恢复状态---------------");
}

- (void)centralManager:(CBCentralManager *)central didFailToConnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error
{
    NSLog(@"-----------------连接失败---------------");
//    if ([peripheral.name isEqualToString:kBlePeripheralName])
//    {
//        [[BleSharedMethod sharedInstance].centralManager connectPeripheral:peripheral options:0];
//    }
    
    NSUserDefaults *BleConnectCache = [NSUserDefaults standardUserDefaults];
    NSString *BleConnectText = [BleConnectCache objectForKey:@"Ble"];
    
    if ([BleConnectText isEqualToString:@"IsConnectBle"]) {
        [[BleSharedMethod sharedInstance].centralManager connectPeripheral:peripheral options:0];
    }
}

- (void)centralManager:(CBCentralManager *)central didDisconnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error
{
    NSLog(@"---------已经断开连接----------");
    [[NSNotificationCenter defaultCenter] postNotificationName:@"PUSHBLEDISCONNECTSTATUS" object:nil];
    if ([peripheral.name isEqualToString:[BleSharedMethod sharedInstance].BleIsConnectName])
    {
        [self.centralManager connectPeripheral:peripheral options:0];
    }
   
    dispatch_async(dispatch_get_main_queue(), ^{
        
        [self disconnectToPeriohereal];
        UIAlertView *alertview = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"温馨提示", nil) message:@"蓝牙已断开，请重新连接蓝牙" delegate:self cancelButtonTitle:NSLocalizedString(@"取消", nil) otherButtonTitles:NSLocalizedString(@"确定", nil), nil];
        [alertview show];
    });
}

- (void)centralManager:(CBCentralManager *)central didConnectPeripheral:(CBPeripheral *)peripheral
{
    NSLog(@"=========第 4 步==========");
    [BleSharedMethod sharedInstance].cbPeripheral.delegate = self;
    [[BleSharedMethod sharedInstance].cbPeripheral discoverServices:nil];
}

- (void)peripheral:(CBPeripheral *)peripheral didDiscoverServices:(NSError *)error
{
    NSLog(@"=========第 5 步==========");
    for (int i=0; i<[[BleSharedMethod sharedInstance].cbPeripheral.services count]; i++)
    {
        CBService *Services1 = [[BleSharedMethod sharedInstance].cbPeripheral .services objectAtIndex:i];
        
        if ([[Services1 UUID] isEqual:[CBUUID UUIDWithString:@"FFF0"]])
        {
            [[BleSharedMethod sharedInstance].cbPeripheral  discoverCharacteristics:nil forService:Services1];//go to find Characteristics id
        }
    }
}


/*
 int header = 0xA5;
 int len = 2; //数据长度：命令和数据和校验加起来的字节个数
 int cmd = 0x01; //0x01获取温控器名称
 int crc8 = 0; //校验码:从数据长度字节开始到最后一个数据crc8校验
 int end1 = 0xD;
 //int end2 = 0xA;
 
 //获取温控器名称,数据格式：0xA5 长度 0x01 crc 0x0d 0x0A
 NSData *data_header = [NSData dataWithBytes:&header length:1]; //0xA5
 NSData *data_len = [NSData dataWithBytes:&len length:1];//长度
 NSData *data_cmd = [NSData dataWithBytes:&cmd length:1];//0x01获取温控器名称
 NSData *data_crc = [NSData dataWithBytes:&crc8 length:1];//crc
 NSData *data_end1 = [NSData dataWithBytes:&end1 length:1];//0x0d
 //NSData *data_end2 = [NSData dataWithBytes:&end2 length:1];//0x0A
 
 
 NSMutableData *data = [[NSMutableData alloc] init];
 [data appendData:data_header];
 [data appendData:data_len];
 [data appendData:data_cmd];
 [data appendData:data_crc];
 [data appendData:data_end1];
 //[data appendData:data_end2];
 
 //再发送data给设备
 */


- (void)peripheral:(CBPeripheral *)peripheral didDiscoverCharacteristicsForService:(CBService *)service error:(NSError *)error
{
    NSLog(@"=========第 6 步==========");
    if (!error)
    {
        for (int i=0; i<[service.characteristics count]; i++)
        {
            CBCharacteristic *Characteristic1 = [service.characteristics objectAtIndex:i];
            NSLog(@"");
            if([Characteristic1.UUID.UUIDString isEqual:@"FFF1"]) {
                
                [BleSharedMethod sharedInstance].ReadCharacteristic = Characteristic1;
                [[BleSharedMethod sharedInstance].cbPeripheral setNotifyValue:YES forCharacteristic:[BleSharedMethod sharedInstance].ReadCharacteristic];
                
                NSLog(@"======================读数据的特征ID  FFFF1===============================");
            }
            else if ([Characteristic1.UUID.UUIDString isEqual:@"FFF2"]){
    
                [BleSharedMethod sharedInstance].WriteCharacteracteristic = Characteristic1;
                
//                //第一种写法
//                Byte byte[] = {0XEB};
//                NSData *xmlData = [NSData dataWithBytes:byte length:sizeof(byte)];
//                [[BleSharedMethod sharedInstance].cbPeripheral writeValue:xmlData forCharacteristic:[BleSharedMethod sharedInstance].WriteCharacteracteristic type:CBCharacteristicWriteWithResponse];
 
                
//                NSString *a = @"123456";
//                const char *ch = [a UTF8String];
//                int len = a.length;
//                uint8_t res = xCal_crc(ch, len);

                
                 NSLog(@"====================== 可以发送数据了 ==============================");
                NSDictionary *dic = @{@"command":@"comm9001",@"uid":@"123456789",@"userid":@"ewed",@"authorization":@"321313",@"phone_uid":@"134256rf4r32423434"};
                NSData *dicData= [NSJSONSerialization dataWithJSONObject:dic options:NSJSONWritingPrettyPrinted error:nil];
                NSDictionary *dictionary =[NSJSONSerialization JSONObjectWithData:dicData options:NSJSONReadingMutableLeaves error:nil];

               NSString *DeviceNameStr = @"My Device";
//                NSData *DeviceNameData =[DeviceNameStr dataUsingEncoding:NSUTF8StringEncoding];
                
                uint8_t NameLen = (uint8_t)dicData;
                Byte *NameByte = (Byte *)[dicData bytes];
                uint8_t nameres = checksum(NameByte, NameLen);//校验
                NSData *nameData = [NSData dataWithBytes:&nameres length:nameres];
                
                //获取蓝牙名称（指令）
                int header = 0xA5;
                int len = 2; //数据长度：命令和数据和校验加起来的字节个数
                int cmd = 0x01; //0x01获取温控器名称
                int crc8 = 0; //校验码:从数据长度字节开始到最后一个数据crc8校验
                int end1 = 0xD;
                int end2 = 0xA;
                
                //获取温控器名称,数据格式：0xA5 长度 0x01 crc 0x0d 0x0A
                NSData *data_header = [NSData dataWithBytes:&header length:1]; //0xA5
                NSData *data_len = [NSData dataWithBytes:&len length:1];//长度
                NSData *data_cmd = [NSData dataWithBytes:&cmd length:1];//0x01获取温控器名称
                NSData *data_crc = [NSData dataWithBytes:&nameres length:sizeof(nameres)];//crc
                NSData *data_end1 = [NSData dataWithBytes:&end1 length:1];//0x0d
                NSData *data_end2 = [NSData dataWithBytes:&end2 length:1];//0x0A
                
                
                NSMutableData *data = [[NSMutableData alloc] init];
                [data appendData:data_header];
                [data appendData:data_len];
                [data appendData:data_cmd];
                [data appendData:data_crc];
                [data appendData:data_end1];
                [data appendData:data_end2];//拼接
                
                [[BleSharedMethod sharedInstance].cbPeripheral writeValue:data forCharacteristic:[BleSharedMethod sharedInstance].WriteCharacteracteristic type:CBCharacteristicWriteWithResponse];//发送data给设备
                
            }
        }
    }
    else
    {
        NSLog(@"Characteristic discorvery unsuccessfull ");
    }
}

//laoixao 写的校验方法
unsigned int Cal_crc8(unsigned char *ptr, int len)
{
    unsigned int crc;
    unsigned int i;
    crc = 0;
    while(len--)
    {
        crc ^= *ptr++;
        for(i = 0;i < 8;i++)
        {
            if(crc & 0x01){
                
                crc = (crc >> 1) ^ 0x8C;
            }
            else{
                crc >>= 1;
                
            }
        }
    }
    return crc;
}

//Dasheng --消息校验（crc算法）
uint8_t xCal_crc(uint8_t *ptr,uint32_t len)
{
    uint8_t crc;
    uint8_t i;
    crc = 0;
    while (len--)
    {
        crc ^= *ptr++;
        for (i=0; i<8; i++) {
            if (crc & 0x01) {
                crc = (crc >> 1) ^ 0x8C;
            }else crc >>= 1;
        }
    }
    return crc;
}

//岳工写的crc计算
//CRC8 = X^8 + X^5 + X^4 + 1
const uint8_t CrcTable [256]={
    0, 94,188,226, 97, 63,221,131,194,156,126, 32,163,253, 31, 65,
    157,195, 33,127,252,162, 64, 30, 95,  1,227,189, 62, 96,130,220,
    35, 125,159,193, 66, 28,254,160,225,191, 93,  3,128,222, 60, 98,
    190,224,  2, 92,223,129, 99, 61,124, 34,192,158, 29, 67,161,255,
    70, 24,250,164, 39,121,155,197,132,218, 56,102,229,187, 89,  7,
    219,133,103, 57,186,228,  6, 88, 25, 71,165,251,120, 38,196,154,
    101, 59,217,135,  4, 90,184,230,167,249, 27, 69,198,152,122, 36,
    248,166, 68, 26,153,199, 37,123, 58,100,134,216, 91,  5,231,185,
    140,210, 48,110,237,179, 81, 15, 78, 16,242,172, 47,113,147,205,
    17, 79,173,243,112, 46,204,146,211,141,111, 49,178,236, 14, 80,
    175,241, 19, 77,206,144,114, 44,109, 51,209,143, 12, 82,176,238,
    50,108,142,208, 83, 13,239,177,240,174, 76, 18,145,207, 45,115,
    202,148,118, 40,171,245, 23, 73,  8, 86,180,234,105, 55,213,139,
    87,  9,235,181, 54,104,138,212,149,203, 41,119,244,170, 72, 22,
    233,183, 85, 11,136,214, 52,106, 43,117,151,201, 74, 20,246,168,
    116, 42,200,150, 21, 75,169,247,182,232, 10, 84,215,137,107, 53,
};

//岳工写的crc计算
uint8_t checksum(uint8_t* data,uint8_t len)
{
    uint8_t i,crc_data=0;
    for(i=0;i<len;i++)  crc_data = CrcTable[crc_data^data[i]];
    return crc_data;
}

- (void)peripheral:(CBPeripheral *)peripheral didUpdateValueForCharacteristic:(nonnull CBCharacteristic *)characteristic error:(nullable NSError *)error
{
    NSLog(@"=========== 第 8 步 ===========================");
    if ([characteristic isEqual:[BleSharedMethod sharedInstance].ReadCharacteristic])
    {
        NSLog(@"蓝牙接收的数据receiveData = %@", characteristic.value);
    }
}

@end
