//
//  BleSharedMethod.h
//  蓝牙模式
//
//  Created by 徐清兰 on 2017/10/23.
//  Copyright © 2017年 何. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import "BleConnectMethod.h"
@interface BleSharedMethod : NSObject
+(BleSharedMethod *)sharedInstance;

@property (nonatomic,assign) BOOL isAllowSendData;
@property (nonatomic,strong) CBPeripheral *cbPeripheral;
@property (nonatomic,strong) CBCharacteristic *writeCharacteristic;

@property (nonatomic,strong) CBCharacteristic *WriteCharacteracteristic;//特征ID
@property (nonatomic,strong) CBCharacteristic *ReadCharacteristic;//特征ID

@property (nonatomic,strong) CBCentralManager *centralManager;
@property (nonatomic,assign) CBManagerState peripheralState;
@property (nonatomic,strong) NSString *writeCharacteristicUUIdStr;
@property (nonatomic,strong) NSString *selectIMEIStr;
@property (nonatomic,strong) NSString *BleIsConnectName;
@property (nonatomic,assign) NSTimer *BleScanTimer;
@property (nonatomic,strong) NSMutableArray *DeviceNameArr;
@property (nonatomic,assign) BOOL isManualDisconnectBle;
@property (nonatomic) BOOL IsOpenBlueTooth;

@end
