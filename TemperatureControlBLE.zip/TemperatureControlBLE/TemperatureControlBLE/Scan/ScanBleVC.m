//
//  ScanBleVC.m
//  TemperatureControlBLE
//
//  Created by 黄文雨 on 2018/9/18.
//  Copyright © 2018年 wenyu. All rights reserved.
//

#import "ScanBleVC.h"
#import "define.h"
#import "defineColor.h"
#import "BleConnectMethod.h"
#import "InvokHeadFile.pch"

@interface ScanBleVC ()
{
    NSTimer *BleScanTimer;
//    UILabel *BleScanTipslb;
//    UILabel *BleScanSmallTipslb;
    UIImageView *RunLoopImgView;
    float angle;
    NSTimer *checkoutBleScanTime;
    BOOL isAllowQuit;
}
@end

@implementation ScanBleVC


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self LoadSubView];

    angle = 0;
    [[BleConnectMethod sharedInstance] centralManager];
    [[BleConnectMethod sharedInstance] scanBle];
    
    BleScanTimer = [NSTimer scheduledTimerWithTimeInterval:0.01 target:self selector:@selector(TransformAction:) userInfo:nil repeats:YES];
    
    double delaySeconds = 2.0;
    dispatch_time_t poptime = dispatch_time(DISPATCH_TIME_NOW, delaySeconds *NSEC_PER_SEC);
    dispatch_after(poptime, dispatch_get_main_queue(), ^(void){
        
        checkoutBleScanTime = [NSTimer scheduledTimerWithTimeInterval:20 target:self selector:@selector(checkoutScanBleDelayTimeAction:) userInfo:nil repeats:NO];
        
        if ([BleSharedMethod sharedInstance].IsOpenBlueTooth==YES) {
            
            isAllowQuit = NO;
        }
        else{
       
            isAllowQuit = YES;
            [BleScanTimer setFireDate:[NSDate distantFuture]];
            dispatch_async(dispatch_get_main_queue(), ^{

                UIAlertView *Alertview = [[UIAlertView alloc] initWithTitle:@"温馨提示" message:@"请打开手机蓝牙" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
                [Alertview show];
            });
        }
    });
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(receiveBleConnectBleStatusAction:) name:@"PUSHCONNECTBLESUCCESSSTATUS" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(receiveBleDisconectStatusAction:) name:@"PUSHBLEDISCONNECTSTATUS" object:nil];
    
    [PassBlock shareInstance].AlreadyFindBleGotoOtherPageBlock = ^{
        NSLog(@"");
    };
    
    [self.BackBtn addTarget:self action:@selector(Back:) forControlEvents:UIControlEventTouchUpInside];
}

-(void)checkoutScanBleDelayTimeAction:(id)send{
    
    if (BleScanTimer!=nil) {
        
        [[BleSharedMethod sharedInstance].centralManager stopScan];
        [BleScanTimer setFireDate:[NSDate distantFuture]];
        isAllowQuit = YES;
        
        dispatch_async(dispatch_get_main_queue(), ^{
            
        });
    }
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    if (buttonIndex==0) {
        [alertView setHidden:YES];
        NSLog(@"");
    }
    else{
        [alertView setHidden:YES];
        NSLog(@"");
    }
}

-(void)receiveBleDisconectStatusAction:(id)send
{
    [BleScanTimer setFireDate:[NSDate distantFuture]];
    isAllowQuit = YES;
}

-(void)checkoutScanBleDeyTimeAction:(id)send
{
    [BleScanTimer setFireDate:[NSDate distantFuture]];
    [[BleConnectMethod sharedInstance] disconnectToPeriohereal];
    isAllowQuit = YES;
    dispatch_async(dispatch_get_main_queue(), ^{
//        BleScanTipslb.text = @"连接失败";
//        BleScanSmallTipslb.text = @"请检查手机蓝牙是否打开,并将手表靠近手机";
    });
}

//-(void)tips:(NSString *)message
//{
//    MBProgressHUD * hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
//    hud.mode = MBProgressHUDModeText;
//    hud.labelText = message;
//    [hud hide:YES afterDelay:2];
//}

//OK
-(void)receiveBleConnectBleStatusAction:(id)Send
{
    dispatch_async(dispatch_get_main_queue(), ^{
        
        if(checkoutBleScanTime!=nil){
            [checkoutBleScanTime invalidate];
            checkoutBleScanTime = nil;
        }
        
        //[BleScanTimer setFireDate:[NSDate distantFuture]];
        [[BleSharedMethod sharedInstance].centralManager stopScan];
        [self dismissViewControllerAnimated:YES completion:nil];
    });
}

-(void)BleScanTimerAction:(id)send
{
    dispatch_async(dispatch_get_main_queue(), ^{
//        BleScanTipslb.text = @"连接失败";
//        BleScanSmallTipslb.text = @"请检查手机蓝牙是否打开,并将手表靠近手机";
    });
}

-(void)LoadSubView{
    
//    self.view.backgroundColor = [UIColor whiteColor];
//    float BarViewH = HeightScreen*0.105;
//    UIView *Barview = [[UIView alloc] initWithFrame:CGRectMake(0, 0, WidthScreen, BarViewH)];
//    Barview.backgroundColor = kUIColorFromRGB(0x00923F);
//    [self.view addSubview:Barview];
//
    BOOL isPhone6 = WidthScreen>320;
//    UIButton *backButton = [[UIButton alloc] initWithFrame:CGRectMake(0,isPhone6?25:18, 45, 45)];
//    if(WidthScreen==414){
//        backButton.frame = CGRectMake(0,30, 45, 45);
//    }
//    else if (HeightScreen==812){
//        backButton.frame = CGRectMake(0,35, 45, 45);
//    }
//    [backButton setBackgroundImage:[UIImage imageNamed:@"ic_actionbar_back_normal"] forState:UIControlStateNormal];
//    [Barview addSubview:backButton];
//    UIButton *backImgBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 100, 60)];
//    backImgBtn.backgroundColor = [UIColor clearColor];
//    [backImgBtn addTarget:self action:@selector(navBack) forControlEvents:UIControlEventTouchUpInside];
//    [Barview addSubview:backImgBtn];
//
//    float hlW = 100;
//    float barVH = HeightScreen*0.105;
//    float btjglgdH = barVH *0.3654;
//    UILabel *headLinelb = [[UILabel alloc]initWithFrame:CGRectMake((WidthScreen-hlW)/2,(barVH-btjglgdH-30)/2+btjglgdH, hlW, 30)];
//    headLinelb.text = @"扫描蓝牙";
//    headLinelb.backgroundColor = [UIColor clearColor];
//    headLinelb.textColor = kUIColorFromRGB(0xFFFFFF);
//    headLinelb.textAlignment = UITextAlignmentCenter;
//    headLinelb.font = [UIFont systemFontOfSize:16.0 weight:UIFontWeightThin];
//    [Barview addSubview:headLinelb];
//
//    CGFloat AnylbW = 250;
//    BleScanTipslb = [[UILabel alloc]initWithFrame:CGRectMake((WidthScreen-AnylbW)/2,BarViewH + 50, AnylbW, 30)];
//    BleScanTipslb.text = @"正在连接设备，请稍后...";
//    BleScanTipslb.backgroundColor = [UIColor clearColor];
//    BleScanTipslb.textColor = kUIColorFromRGB(0x333333);
//    BleScanTipslb.textAlignment = UITextAlignmentCenter;
//    BleScanTipslb.font = [UIFont systemFontOfSize:16.0];
//    [Barview addSubview:BleScanTipslb];
//
//    BleScanSmallTipslb = [[UILabel alloc]initWithFrame:CGRectMake((WidthScreen-AnylbW)/2,BleScanTipslb.frame.origin.y + 30, AnylbW, 30)];
//    BleScanSmallTipslb.text = @"请靠近您的手表";
//    BleScanSmallTipslb.backgroundColor = [UIColor clearColor];
//    BleScanSmallTipslb.textColor = kUIColorFromRGB(0x333333);
//    BleScanSmallTipslb.textAlignment = UITextAlignmentCenter;
//    BleScanSmallTipslb.font = [UIFont systemFontOfSize:12.0 weight:UIFontWeightThin];
//    [Barview addSubview:BleScanSmallTipslb];
    
    UIButton *againScanBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    againScanBtn.frame = CGRectMake((WidthScreen-200)/2,HeightScreen-130,200,40);
    [againScanBtn.layer setCornerRadius:5.0];
    [againScanBtn.layer setMasksToBounds:YES];
    [againScanBtn.layer setBorderWidth:0];
    againScanBtn.titleLabel.font = [UIFont systemFontOfSize:16.0 weight:UIFontWeightThin];
    againScanBtn.backgroundColor = BackGroundGaryColor;
    [againScanBtn setTitle:@"重新连接" forState:UIControlStateNormal];
    [againScanBtn setTitleColor:kUIColorFromRGB(0xFFFFFF) forState:UIControlStateNormal];
    [againScanBtn addTarget:self action:@selector(againScanBle:) forControlEvents:UIControlEventTouchUpInside];
    againScanBtn.adjustsImageWhenHighlighted = NO;
    [self.view addSubview:againScanBtn];
    
    
    UIButton *sendBtn = [[UIButton alloc] initWithFrame:CGRectMake((ScrWidth-120)/2, againScanBtn.frame.origin.y+65, 120, 30)];
    sendBtn.backgroundColor = [UIColor colorWithRed:178.0/255.0 green:179.0/255.0 blue:180.0/255.0 alpha:1.0];
    [sendBtn addTarget:self action:@selector(SendBtn:) forControlEvents:UIControlEventTouchUpInside];
    [sendBtn setTitle:NSLocalizedString(@"Send", nil) forState:UIControlStateNormal];
    sendBtn.layer.cornerRadius = 5;
    sendBtn.layer.masksToBounds = YES;
    [self.view addSubview:sendBtn];
    
    CGFloat ImgWH = WidthScreen*0.67;
    UIView *backView = [[UIView alloc] initWithFrame:CGRectMake((WidthScreen-ImgWH)/2, (HeightScreen-ImgWH)/2+ (isPhone6?50:30), ImgWH, ImgWH)];
    [self.view addSubview:backView];
    
    angle = 1.0;
    RunLoopImgView = [[UIImageView alloc]init];
    RunLoopImgView.frame = CGRectMake(0, 0, ImgWH, ImgWH);
    RunLoopImgView.image = [UIImage imageNamed:@"bluetooth_09_07.png"];
    [self.view setBackgroundColor:[UIColor whiteColor]];
    [backView addSubview:RunLoopImgView];
    CGAffineTransform transform= CGAffineTransformMakeRotation(M_PI*0.98);
    RunLoopImgView.transform = transform;
    
    CGFloat BleImgWH = 45;
    UIImageView *BleImg = [[UIImageView alloc] initWithFrame:CGRectMake((ImgWH-BleImgWH)/2, (ImgWH-BleImgWH)/2, BleImgWH, BleImgWH)];
    BleImg.image = [UIImage imageNamed:@"bluetooth_07"];
    [backView addSubview:BleImg];
}

-(void)SendBtn:(id)send{
   
//    [BleSharedMethod sharedInstance].cbPeripheral.delegate = self;
//    Byte byte[] = {0XEB};
//    NSData *xmlData = [[NSData alloc] initWithBytes:byte length:1];
//    [[BleSharedMethod sharedInstance].cbPeripheral writeValue:xmlData forCharacteristic:[BleSharedMethod sharedInstance].WriteCharacteracteristic type:CBCharacteristicWriteWithResponse];
//    NSLog(@"外围: = %@",[BleSharedMethod sharedInstance].cbPeripheral);
//    NSLog(@"特征: = %@",[BleSharedMethod sharedInstance].WriteCharacteracteristic);
    [[NSNotificationCenter defaultCenter] postNotificationName:@"SENDDATA" object:nil];
}

-(void)TransformAction:(id)send {
    
    angle = angle + 0.02;
    if (angle > 6.28) {
        angle = 0;
    }
    CGAffineTransform transform = CGAffineTransformMakeRotation(angle);
    RunLoopImgView.transform = transform;
}

//重新连接
-(void)againScanBle:(id)send{
    
    if(isAllowQuit==YES){
        
        [[BleConnectMethod sharedInstance] centralManager];
        [[BleConnectMethod sharedInstance] scanBle];
        
        [BleScanTimer setFireDate:[NSDate distantPast]];
       
        isAllowQuit = NO;
        
        double delaySeconds = 2.0;
        dispatch_time_t poptime = dispatch_time(DISPATCH_TIME_NOW, delaySeconds *NSEC_PER_SEC);
        dispatch_after(poptime, dispatch_get_main_queue(), ^(void){
            
            if([BleSharedMethod sharedInstance].IsOpenBlueTooth==YES){
                
                checkoutBleScanTime = [NSTimer scheduledTimerWithTimeInterval:25 target:self selector:@selector(checkoutScanBleDelayTimeAction:) userInfo:nil repeats:NO];
            }
            else{
                
                isAllowQuit = YES;
                [BleScanTimer setFireDate:[NSDate distantFuture]];
                dispatch_async(dispatch_get_main_queue(), ^{
                  
                });
            }
        });
    }
}

-(void)Back:(id)send
{
    [self.navigationController popViewControllerAnimated:YES];
//    if (isAllowQuit==YES) {
//
//        if (BleScanTimer!=nil) {
//
//            [BleScanTimer invalidate];
//            BleScanTimer = nil;
//            [[BleSharedMethod sharedInstance].centralManager stopScan];
//            [[BleConnectMethod sharedInstance] disconnectToPeriohereal];
//        }
//        [self.navigationController popViewControllerAnimated:YES];
//
//        //        if ([BlockMethod shareInstance].ReturnMainPageBlock) {
//        //            [BlockMethod shareInstance].ReturnMainPageBlock();
//        //        }
//    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
