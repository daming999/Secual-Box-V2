//
//  BleClientBlock.h
//  OldManHappy
//
//  Created by 徐清兰 on 2017/11/16.
//  Copyright © 2017年 何. All rights reserved.
//

#import <Foundation/Foundation.h>
typedef void (^blockGetBleAllData)(NSString *AllStr);
@interface BleClientBlock : NSObject

@property (nonatomic,copy) blockGetBleAllData blockBleAllDataMethod;

+(BleClientBlock *)sharedInstance;
@end
