//
//  BleSharedMethod.m
//  蓝牙模式
//
//  Created by 徐清兰 on 2017/10/23.
//  Copyright © 2017年 何. All rights reserved.
//

#import "BleSharedMethod.h"

@implementation BleSharedMethod
static BleSharedMethod *Share = nil;

+(BleSharedMethod *)sharedInstance
{
    if (Share==nil) {
        Share = [[BleSharedMethod alloc] init];
    }
    return Share;
}
@end
