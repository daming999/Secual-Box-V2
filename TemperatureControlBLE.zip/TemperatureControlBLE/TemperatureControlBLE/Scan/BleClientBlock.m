//
//  BleClientBlock.m
//  OldManHappy
//
//  Created by 徐清兰 on 2017/11/16.
//  Copyright © 2017年 何. All rights reserved.
//

#import "BleClientBlock.h"

@implementation BleClientBlock
static BleClientBlock *share = nil;
+(BleClientBlock *)sharedInstance
{
    if (share==nil) {
        share = [[BleClientBlock alloc] init];
    }
    return share;
}

@end
